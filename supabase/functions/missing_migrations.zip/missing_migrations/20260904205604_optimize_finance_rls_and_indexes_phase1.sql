-- Phase 1: fix RLS initplan performance issue causing statement timeouts on
-- short_term_agreements / short_term_agreement_payments / appointments / audit_logs.
-- Pure optimization: wraps auth.uid()/helper-function calls in (select ...) so
-- Postgres evaluates them once per query instead of once per row. No access
-- semantics are changed (same booleans, same OR logic).

-- ===== short_term_agreements =====
ALTER POLICY "Main admin full access to short term agreements" ON public.short_term_agreements
USING ((select is_system_admin()))
WITH CHECK ((select is_system_admin()));

ALTER POLICY "Finance and director can view all short term agreements" ON public.short_term_agreements
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Referring attorneys can view their agreements" ON public.short_term_agreements
USING (referring_attorney_id IS NOT NULL AND referring_attorney_id = (select get_current_user_referring_attorney()));

ALTER POLICY "Finance and director can update short term agreements" ON public.short_term_agreements
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role))
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

-- ===== short_term_agreement_payments =====
ALTER POLICY "Main admin full access to agreement payments" ON public.short_term_agreement_payments
USING ((select is_system_admin()))
WITH CHECK ((select is_system_admin()));

ALTER POLICY "Finance and director can create short term agreement payments" ON public.short_term_agreement_payments
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Finance and director can view all short term agreement payments" ON public.short_term_agreement_payments
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

-- ===== appointments =====
ALTER POLICY "Main admin full access to appointments" ON public.appointments
USING ((select is_system_admin()))
WITH CHECK ((select is_system_admin()));

ALTER POLICY "Users can delete appointments from their referring attorney" ON public.appointments
USING (referring_attorney_id = (select get_current_user_referring_attorney()));

ALTER POLICY "Users can create appointments for their referring attorney" ON public.appointments
WITH CHECK (referring_attorney_id = (select get_current_user_referring_attorney()));

ALTER POLICY "Admins and employees can view all appointments for debt managem" ON public.appointments
USING (
  has_role((select auth.uid()), 'admin'::app_role)
  OR has_role((select auth.uid()), 'employee'::app_role)
  OR (
    (NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
    AND referring_attorney_id = (select get_current_user_referring_attorney())
  )
);

ALTER POLICY "Users can view appointments from their referring attorney" ON public.appointments
USING (
  deleted_at IS NULL
  AND (
    ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
      AND referring_attorney_id = (select get_current_user_referring_attorney()))
    OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope
      AND referring_attorney_id = (select get_current_user_referring_attorney()))
    OR ((select get_current_user_portal_account_scope()) = 'individual'::external_portal_account_scope
      AND assigned_attorney_contact_id IS NOT NULL
      AND assigned_attorney_contact_id = (select get_current_user_attorney_contact()))
    OR ((select get_current_user_expert_id()) IS NOT NULL
      AND expert_id = (select get_current_user_expert_id()))
  )
);

ALTER POLICY "Users can view deleted appointments from their referring attorn" ON public.appointments
USING (referring_attorney_id = (select get_current_user_referring_attorney()) AND deleted_at IS NOT NULL);

ALTER POLICY "Finance and director can update appointments for payments" ON public.appointments
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role))
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can update appointments from their referring attorney" ON public.appointments
USING (
  ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
    AND referring_attorney_id = (select get_current_user_referring_attorney()))
  OR (assigned_attorney_contact_id IS NOT NULL AND assigned_attorney_contact_id = (select get_current_user_attorney_contact()))
  OR (expert_id IS NOT NULL AND expert_id = (select get_current_user_expert_id()))
)
WITH CHECK (
  ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
    AND referring_attorney_id = (select get_current_user_referring_attorney()))
  OR (assigned_attorney_contact_id IS NOT NULL AND assigned_attorney_contact_id = (select get_current_user_attorney_contact()))
  OR (expert_id IS NOT NULL AND expert_id = (select get_current_user_expert_id()))
);

-- ===== audit_logs =====
ALTER POLICY "Users can view audit logs from their law firm" ON public.audit_logs
USING (
  (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = (select auth.uid())
    AND (profiles.role = 'admin'::text
      OR profiles.referring_attorney_id = (SELECT p2.referring_attorney_id FROM profiles p2 WHERE p2.id = audit_logs.user_id))
  ))
  OR (user_id = (select auth.uid()))
  OR (table_name = 'medical_experts'::text AND (
    has_role((select auth.uid()), 'admin'::app_role)
    OR has_role((select auth.uid()), 'employee'::app_role)
    OR (select user_has_permission('manage_experts'::text))
  ))
);

-- ===== index cleanup on short_term_agreements =====
-- drop duplicate btree indexes on referring_attorney_id, keep one
DROP INDEX IF EXISTS public.idx_short_term_agreements_law_firm;
DROP INDEX IF EXISTS public.idx_sta_attorney;
-- drop duplicate GIN index on linked_appointment_ids, keep one
DROP INDEX IF EXISTS public.idx_sta_linked_appointments_gin;

-- add missing covering index for the FK from short_term_agreement_payments
CREATE INDEX IF NOT EXISTS idx_short_term_agreement_payments_agreement_id
  ON public.short_term_agreement_payments (agreement_id);
