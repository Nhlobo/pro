-- Position-based access control (Phase: wiring staff_positions / role_position_rules /
-- staff_access_profiles into actual module gating, which previously had zero effect
-- on what a user could see -- only role_key drove access before this migration).

-- 1. RLS for the three existing-but-previously-unreadable position tables.
-- They were created with RLS enabled and NO policies, which is a silent deny-all --
-- the frontend could never have read them even if it tried.

CREATE POLICY staff_positions_select_authenticated
  ON public.staff_positions FOR SELECT
  USING (true);

CREATE POLICY staff_positions_write_admin_only
  ON public.staff_positions FOR ALL
  USING (is_new_system_admin(auth.uid()))
  WITH CHECK (is_new_system_admin(auth.uid()));

CREATE POLICY role_position_rules_select_authenticated
  ON public.role_position_rules FOR SELECT
  USING (true);

CREATE POLICY role_position_rules_write_admin_only
  ON public.role_position_rules FOR ALL
  USING (is_new_system_admin(auth.uid()))
  WITH CHECK (is_new_system_admin(auth.uid()));

-- staff_access_profiles: a user can read their own row (to resolve their own
-- access client-side, same pattern as access_role_assignments); admins can
-- read/write everyone's.
CREATE POLICY staff_access_profiles_select_own_or_admin
  ON public.staff_access_profiles FOR SELECT
  USING (user_id = auth.uid() OR is_new_system_admin(auth.uid()));

CREATE POLICY staff_access_profiles_write_admin_only
  ON public.staff_access_profiles FOR ALL
  USING (is_new_system_admin(auth.uid()))
  WITH CHECK (is_new_system_admin(auth.uid()));

-- 2. New table: position-level module overrides. Sits between the role's
-- defaults and a user's personal override in the precedence chain, so an
-- admin can restrict (or loosen, within what the role is eligible for) an
-- entire position -- e.g. "Admin Assistant" -- without touching the base
-- "admin" role (which stays full-access for the "admin" position / real
-- admins) and without hand-editing every individual user.
CREATE TABLE public.position_module_overrides (
  position_key text NOT NULL REFERENCES public.staff_positions(position_key) ON DELETE CASCADE,
  module_key text NOT NULL REFERENCES public.access_modules(module_key) ON DELETE CASCADE,
  granted boolean NOT NULL,
  reason text,
  granted_by uuid,
  granted_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (position_key, module_key)
);

ALTER TABLE public.position_module_overrides ENABLE ROW LEVEL SECURITY;

CREATE POLICY position_module_overrides_select_authenticated
  ON public.position_module_overrides FOR SELECT
  USING (true);

CREATE POLICY position_module_overrides_write_admin_only
  ON public.position_module_overrides FOR ALL
  USING (is_new_system_admin(auth.uid()))
  WITH CHECK (is_new_system_admin(auth.uid()));

COMMENT ON TABLE public.position_module_overrides IS
  'Per-position module grant/deny, applied after role_module_defaults and before
   user_module_overrides. Only takes effect for module_keys the role is already
   eligible for (role_module_defaults.is_eligible = true) -- a position can never
   unlock a module its role was never meant to see at all.';
