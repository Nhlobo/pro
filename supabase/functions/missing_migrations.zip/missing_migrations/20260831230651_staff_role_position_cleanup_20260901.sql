
-- 2a. Sync profiles.position display text to match existing, correct staff_access_profiles assignment.
update profiles p
set position = sp.display_name
from staff_access_profiles sap
join staff_positions sp on sp.position_key = sap.position_key and sp.role_key = sap.role_key
where sap.user_id = p.id
  and sap.is_active
  and p.user_type is distinct from 'external_portal'
  and p.position is distinct from sp.display_name;

-- 2b. Assign the single valid position for roles with exactly one (finance, director, sales_consultant)
-- where no active assignment exists yet.
insert into staff_access_profiles (user_id, role_key, position_key, is_active)
select p.id, p.role, spr.position_key, true
from profiles p
join (
  select role_key, min(position_key) as position_key, count(*) as n
  from staff_positions where is_active
  group by role_key
  having count(*) = 1
) spr on spr.role_key = p.role
left join staff_access_profiles sap on sap.user_id = p.id
where p.user_type is distinct from 'external_portal'
  and (sap.user_id is null or sap.is_active = false)
on conflict (user_id) do update
  set role_key = excluded.role_key,
      position_key = excluded.position_key,
      is_active = true,
      updated_at = now();

-- 2c. Assign NEG/RAF Case Manager for employees whose current free-text position clearly names one,
-- where no active assignment exists yet.
insert into staff_access_profiles (user_id, role_key, position_key, is_active)
select
  p.id, 'employee',
  case when p.position ilike '%raf%' then 'raf_case_manager' else 'neg_case_manager' end,
  true
from profiles p
left join staff_access_profiles sap on sap.user_id = p.id
where p.user_type is distinct from 'external_portal'
  and p.role = 'employee'
  and (sap.user_id is null or sap.is_active = false)
  and (p.position ilike '%raf%' or p.position ilike '%neg%')
on conflict (user_id) do update
  set role_key = excluded.role_key,
      position_key = excluded.position_key,
      is_active = true,
      updated_at = now();

-- 2d. Re-sync profiles.position display text now that 2b/2c may have created new assignments.
update profiles p
set position = sp.display_name
from staff_access_profiles sap
join staff_positions sp on sp.position_key = sap.position_key and sp.role_key = sap.role_key
where sap.user_id = p.id
  and sap.is_active
  and p.user_type is distinct from 'external_portal'
  and p.position is distinct from sp.display_name;
