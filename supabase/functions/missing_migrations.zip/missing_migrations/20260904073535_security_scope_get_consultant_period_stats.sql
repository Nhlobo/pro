-- get_consultant_period_stats had no caller-identity filtering at all — it
-- returned every consultant's appointment counts to whoever called it, and
-- the frontend (useSalesIncentives.tsx `fetchMyData`) relied entirely on
-- client-side filtering to show only "my" numbers. The raw response still
-- went to every sales consultant's browser regardless.
--
-- Matching the visibility rule already used consistently on
-- monthly_performance / sales_consultants / consultant_strikes RLS
-- (admin, employee, or director see everyone; everyone else sees only their
-- own row via sales_consultants.user_id = auth.uid()), not just admin —
-- since get_consultant_deal_details (the more sensitive sibling function,
-- with claimant names) only checks admin, checked that this doesn't create a
-- new inconsistency: fetchAllData() (the team view) is only reachable by
-- admin/employee/director in the frontend, and this function now correctly
-- serves data to exactly that same set, so the two stay in sync with what
-- the UI actually shows them.

CREATE OR REPLACE FUNCTION public.get_consultant_period_stats(p_start date, p_end date)
 RETURNS TABLE(consultant_id uuid, raf_appts bigint, medneg_appts bigint, total_appts bigint)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT
    a.sales_consultant_id AS consultant_id,
    COUNT(*) FILTER (WHERE LOWER(COALESCE(a.matter_type, '')) NOT LIKE '%neg%') AS raf_appts,
    COUNT(*) FILTER (WHERE LOWER(COALESCE(a.matter_type, '')) LIKE '%neg%') AS medneg_appts,
    COUNT(*) AS total_appts
  FROM public.appointments a
  WHERE a.deleted_at IS NULL
    AND a.sales_consultant_id IS NOT NULL
    AND a.appointment_date::date >= p_start
    AND a.appointment_date::date <= p_end
    AND (
      LOWER(COALESCE(a.matter_type, '')) IN ('mva', 'raf', 'road accident fund', 'medical negligence')
      OR LOWER(COALESCE(a.matter_type, '')) LIKE '%med%neg%'
    )
    AND (
      public.has_role(auth.uid(), 'admin'::app_role)
      OR public.has_role(auth.uid(), 'employee'::app_role)
      OR public.has_role(auth.uid(), 'director'::app_role)
      OR a.sales_consultant_id IN (
        SELECT sc.id FROM public.sales_consultants sc WHERE sc.user_id = auth.uid()
      )
    )
  GROUP BY a.sales_consultant_id;
$function$;
