-- Finance and Director currently have SELECT-only RLS on the tables behind
-- the Finance dashboard (AOD tab, Short-Term Agreement tab, Record Payment
-- action). Every write the dashboard performs -- recording a payment,
-- allocating a report to a claimant, "Sync All Payments", and the quiet
-- background recalculation on every page load -- silently fails or throws
-- for these two roles, which is what shows up as stuck loading, "retry",
-- and stale figures on the Finance pages while Admin (which has full access
-- via is_system_admin()) works fine.
--
-- This does not touch any existing admin/employee/case-manager/negligence
-- manager policy. It only adds the missing write policies for
-- finance/director, scoped to exactly the tables the finance payment flow
-- touches, mirroring the role-only pattern already used elsewhere (e.g.
-- "Employees can update appointments").

-- 1. aod_documents: recalculation + payment recording update totals/status.
CREATE POLICY "Finance and director can update AOD documents"
ON public.aod_documents
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role))
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

-- 2. aod_payments: recording a new AOD payment, and any correction to one.
CREATE POLICY "Finance and director can create AOD payments"
ON public.aod_payments
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

CREATE POLICY "Finance and director can update AOD payments"
ON public.aod_payments
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role))
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

-- 3. short_term_agreements: recalculation from live appointments (Sync,
-- background refresh, and every payment recorded against the agreement).
CREATE POLICY "Finance and director can update short term agreements"
ON public.short_term_agreements
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role))
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

-- 4. short_term_agreement_payments: recording a payment against a
-- short-term agreement (this is the exact "Finance Payment" / short-term
-- tab action the finance role needs).
CREATE POLICY "Finance and director can create short term agreement payments"
ON public.short_term_agreement_payments
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

-- 5. appointments: marking the specific appointment(s) a payment was
-- allocated to as paid/deposit, mirroring the existing employee UPDATE
-- policy (role-scoped only, same as that policy -- not a new looser
-- standard than what already exists in this table).
CREATE POLICY "Finance and director can update appointments for payments"
ON public.appointments
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role))
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

-- 6. expert_reports: marking a report "taken out" / paid when a payment is
-- recorded, including creating the report row if one doesn't exist yet.
CREATE POLICY "Finance and director can update expert reports for payments"
ON public.expert_reports
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role))
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

CREATE POLICY "Finance and director can create expert reports for payments"
ON public.expert_reports
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

-- 7. payment_report_allocations: this table had NO policy at all for
-- finance/director (not even SELECT), so the Record Payment dialog's
-- claimant list and payment history came back empty/blocked for these
-- roles even before any write was attempted.
CREATE POLICY "Finance and director can view payment allocations"
ON public.payment_report_allocations
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));

CREATE POLICY "Finance and director can create payment allocations"
ON public.payment_report_allocations
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role));
