-- Repair the specific account affected by the bridge/ranking bug fixed in
-- migrations 20260830_fix_get_current_user_role_staff_ranking and
-- 20260830_widen_external_portal_not_staff_guard.
--
-- worksof26@gmail.com was already a genuine External Portal login
-- (referring attorney contact "L Molepo Attorneys") from 20 Aug onward.
-- On 28 Aug an admin separately created an INTERNAL staff account
-- (Finance) using the SAME email address, unaware of the existing
-- external contact. On 29 Aug the same person logged into the External
-- Portal again; the bridge found the existing (internal) auth user by
-- email, its staff guard did not recognise 'finance' as a staff role,
-- and it bolted a referring_attorney role + external portal identity
-- onto the internal Finance account -- overwriting its role, user_type,
-- and name fields with the attorney contact's.
--
-- This migration removes the erroneous referring_attorney role and
-- restores the account to a working internal Finance identity. The
-- attorney-contact name fields it was overwritten with are cleared
-- (not guessed) — an admin needs to re-enter this person's real name
-- via User Management. This does NOT restore the attorney's own portal
-- access: worksof26@gmail.com must be corrected to a unique email on
-- the "L Molepo Attorneys" external contact record, since (by design,
-- after the staff-guard fix) that email can no longer be bridged into
-- the external portal while it belongs to internal staff.

DELETE FROM public.user_roles
WHERE user_id = 'e11ccfe2-7442-4642-88fc-fc908d6a2000'
  AND role = 'referring_attorney'
  AND granted_by IS NULL;

UPDATE public.profiles
SET
  role = 'finance',
  user_type = 'user',
  is_external_portal_user = false,
  first_name = NULL,
  last_name = NULL,
  referring_attorney_id = NULL,
  attorney_contact_id = NULL,
  expert_id = NULL
WHERE id = 'e11ccfe2-7442-4642-88fc-fc908d6a2000';
