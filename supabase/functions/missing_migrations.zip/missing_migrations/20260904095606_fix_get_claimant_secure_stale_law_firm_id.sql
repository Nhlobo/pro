-- Same stale-rename bug as can_view_expert_contacts: claimants.law_firm_id
-- was renamed to referring_attorney_id. Not currently called from the
-- frontend (no live UI feature hits this yet), but fixing it now so it
-- doesn't become the next silent landmine. Output column name kept as
-- law_firm_id so any future caller relying on that shape isn't broken.
CREATE OR REPLACE FUNCTION public.get_claimant_secure(claimant_id uuid)
 RETURNS TABLE(id uuid, auto_id text, first_name_masked text, last_name_masked text, contact_number_masked text, law_firm_id uuid, created_at timestamp with time zone)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  -- Log the access attempt for audit trail
  SELECT public.log_sensitive_data_access('claimants', $1, 'claimant_pii_access');

  SELECT
    c.id,
    c.auto_id,
    CASE
      WHEN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
      THEN c.first_name
      ELSE public.mask_sensitive_data('address', c.first_name)
    END as first_name_masked,
    CASE
      WHEN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
      THEN c.last_name
      ELSE public.mask_sensitive_data('address', c.last_name)
    END as last_name_masked,
    CASE
      WHEN EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
      THEN c.contact_number
      ELSE public.mask_sensitive_data('phone', c.contact_number)
    END as contact_number_masked,
    c.referring_attorney_id as law_firm_id,
    c.created_at
  FROM public.claimants c
  WHERE c.id = $1
    AND public.validate_claimant_access(c.referring_attorney_id);
$function$;
