
CREATE OR REPLACE FUNCTION public.auto_create_sales_consultant()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Only Sales Consultants belong in sales_consultants. This used to fire
  -- unconditionally for every new profile (admin, employee, finance,
  -- director, even external-portal referring attorneys), silently
  -- enrolling every new hire as an "active sales consultant" -- polluting
  -- the pool that team targets, payouts, and strikes are computed from.
  IF NEW.role = 'sales_consultant' THEN
    INSERT INTO public.sales_consultants (user_id, name, type, region, is_active)
    VALUES (NEW.id, NEW.first_name || ' ' || NEW.last_name, 'internal', 'All', true)
    ON CONFLICT (user_id) DO UPDATE SET is_active = true;
  END IF;
  RETURN NEW;
END;
$function$;
