-- Same gap as claimants/medical_experts/referring_attorneys earlier: these
-- tables back the Sales Dashboard (deals, incentives, targets, strikes) but
-- were never added to the realtime publication, so admin edits to a
-- consultant's monthly_performance, a target, or a strike never reach an
-- open Sales Dashboard until the page is fully remounted.
ALTER PUBLICATION supabase_realtime ADD TABLE public.sales_consultants;
ALTER PUBLICATION supabase_realtime ADD TABLE public.monthly_performance;
ALTER PUBLICATION supabase_realtime ADD TABLE public.consultant_strikes;
ALTER PUBLICATION supabase_realtime ADD TABLE public.attorney_pitchlog;
ALTER PUBLICATION supabase_realtime ADD TABLE public.targets;
