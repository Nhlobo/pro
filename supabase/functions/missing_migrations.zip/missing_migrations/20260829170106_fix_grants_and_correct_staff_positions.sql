-- 1. THE ACTUAL BUG behind "failed to update staff/user position": these four
-- tables were created directly against the live DB (no committed migration)
-- and never received the standard Supabase GRANT to `authenticated` beyond
-- SELECT/REFERENCES/TRIGGER. RLS policies were correct, but Postgres checks
-- the base table grant BEFORE it even evaluates RLS -- so every insert/update,
-- even from a real admin who passed every RLS check, was rejected outright
-- with "permission denied for table X". This affected staff_access_profiles
-- (the new Staff Position picker) AND access_role_assignments (the existing
-- System Role picker, which is why it already had a soft "failed to sync"
-- warning toast in the code -- it's been silently failing there too).
GRANT INSERT, UPDATE, DELETE ON public.access_role_assignments TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.staff_positions TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.role_position_rules TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.staff_access_profiles TO authenticated;

-- 2. Harden: anon had INSERT/UPDATE/DELETE on all four (RLS still blocked it
-- since auth.uid() is null for anon, but there's no reason to grant it at
-- all -- defense in depth, matches "authenticated-only writes" intent).
REVOKE INSERT, UPDATE, DELETE ON public.access_role_assignments FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.staff_positions FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.role_position_rules FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.staff_access_profiles FROM anon;

-- 3. Correct Kamohelo Maledi: she is a NEG (medical negligence) case
-- manager, not an administrator and not Admin Assistant. Her access_role_
-- assignments row had role_key = 'admin' (full system access, including
-- Finance and IAM) -- downgrading to 'employee', the correct role for a
-- case manager position, and fixing her staff_access_profiles position
-- from the mismatched 'raf_case_manager' to the correct 'neg_case_manager'.
UPDATE public.access_role_assignments
SET role_key = 'employee'
WHERE user_id = '58e0aaa0-d1fd-45ab-9a50-0cdc67c5aced';

UPDATE public.staff_access_profiles
SET role_key = 'employee', position_key = 'neg_case_manager', updated_at = now()
WHERE user_id = '58e0aaa0-d1fd-45ab-9a50-0cdc67c5aced';

-- 4. Itebogeng Moloto was on file as position 'admin_assistant' under
-- role_key 'admin' in staff_access_profiles, but her actual assigned role
-- (access_role_assignments, the real source of truth) is 'employee' -- a
-- stale/incorrect record. Per confirmation that no one currently holds the
-- Admin Assistant position, deactivating it (not deleting, so the history
-- of who set what stays intact) and correcting the role_key field to match
-- her real role so the row isn't self-contradictory while inactive.
UPDATE public.staff_access_profiles
SET is_active = false, role_key = 'employee', position_key = NULL, updated_at = now()
WHERE user_id = '3c734726-fd74-4780-a2b6-614f92b5c923';
