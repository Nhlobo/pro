-- Restores cross-consultant law-firm autocomplete in AddAttorneyDialog.tsx,
-- which broke (silently narrowed to "own rows only") once attorney_pitchlog
-- RLS was scoped per-consultant. This function intentionally exposes only
-- the 4 fields the autocomplete ever used -- never sales_person,
-- consultant_id, pitch_status, deal_closed, or anything else that would
-- re-expose who is pitching what to whom.
CREATE OR REPLACE FUNCTION public.search_pitchlog_firm_suggestions(p_search text)
RETURNS TABLE(law_firm_name text, contact_person text, email text, telephone text, province text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF p_search IS NULL OR length(trim(p_search)) < 2 THEN
    RETURN;
  END IF;

  -- Only for roles that could already reach AddAttorneyDialog in the app.
  IF NOT (
    has_role(auth.uid(), 'sales_consultant'::app_role)
    OR has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'employee'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.role = ANY (ARRAY['admin', 'employee'])
    )
  ) THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT DISTINCT ON (lower(trim(ap.law_firm_name)))
    ap.law_firm_name, ap.contact_person, ap.email, ap.telephone, ap.province
  FROM public.attorney_pitchlog ap
  WHERE ap.law_firm_name ILIKE '%' || p_search || '%'
  ORDER BY lower(trim(ap.law_firm_name)), ap.created_at DESC
  LIMIT 5;
END;
$function$;
