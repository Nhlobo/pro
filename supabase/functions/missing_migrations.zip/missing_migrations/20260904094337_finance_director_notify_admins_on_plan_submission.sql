-- Expert Payment Planner: when finance/director submit a plan for
-- approval, the page notifies every admin by inserting a notifications
-- row addressed to each admin's user_id. The existing INSERT policy only
-- allows a user to insert a notification for themselves, or an
-- admin/employee to insert one for anyone -- so finance/director's
-- "notify the admins" call was silently blocked by RLS (caught by a
-- try/catch, so the page didn't error, but admins never got notified).
-- Scoped narrowly to the payment-plan-approval workflow, not a general
-- "finance can message anyone" grant.
CREATE POLICY "Finance and director can notify admins of approval requests"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (
  (has_role(auth.uid(), 'finance'::app_role) OR has_role(auth.uid(), 'director'::app_role))
  AND category = 'payment'
  AND related_table = 'expert_payment_planner'
  AND has_role(user_id, 'admin'::app_role)
);
