-- Advisory module gaps identified during audit (client spec sections 9, 10):
-- analyses were standalone (not tied to a case/claimant) and had no human
-- review workflow. This migration is additive only — no existing column
-- is changed or removed, nothing existing can break.

ALTER TABLE public.negligence_analysis_history
  ADD COLUMN case_id uuid REFERENCES public.appointments(id) ON DELETE SET NULL,
  ADD COLUMN claimant_id uuid REFERENCES public.claimants(id) ON DELETE SET NULL,
  -- Denormalised copy of analysis_result->'meritOpinion'->>'opinion' as a
  -- real, indexable/filterable column instead of only living in JSONB.
  -- Nullable + backfilled below rather than a generated column, because
  -- staff review (added below) can override it independently of the
  -- original AI output.
  ADD COLUMN ai_opinion text,
  -- Staff-facing outcome after review. Starts equal to ai_opinion (or
  -- NULL if ai_opinion itself is NULL) and can diverge once a reviewer
  -- acts. 'defer' is a NEW value not yet produced by the AI (see the
  -- edge-function follow-up) but the workflow needs to support it now.
  ADD COLUMN final_opinion text,
  ADD COLUMN review_status text NOT NULL DEFAULT 'pending_review',
  ADD COLUMN reviewed_by uuid REFERENCES auth.users(id),
  ADD COLUMN reviewed_at timestamptz,
  ADD COLUMN reviewer_notes text,
  ADD CONSTRAINT negligence_analysis_history_review_status_check
    CHECK (review_status IN ('pending_review', 'in_review', 'approved', 'rejected')),
  ADD CONSTRAINT negligence_analysis_history_opinion_check
    CHECK (ai_opinion IS NULL OR ai_opinion IN ('possible_negligence', 'no_clear_negligence', 'defer')),
  ADD CONSTRAINT negligence_analysis_history_final_opinion_check
    CHECK (final_opinion IS NULL OR final_opinion IN ('possible_negligence', 'no_clear_negligence', 'defer'));

CREATE INDEX idx_negligence_analysis_case_id ON public.negligence_analysis_history(case_id) WHERE case_id IS NOT NULL;
CREATE INDEX idx_negligence_analysis_review_status ON public.negligence_analysis_history(review_status);

-- Backfill ai_opinion from existing JSONB results (14 existing rows)
UPDATE public.negligence_analysis_history
SET ai_opinion = analysis_result->'meritOpinion'->>'opinion'
WHERE analysis_result ? 'meritOpinion';

COMMENT ON COLUMN public.negligence_analysis_history.case_id IS 'Links this Advisory analysis to a specific case (appointments.id). NULL for legacy/standalone analyses run before this linkage existed.';
COMMENT ON COLUMN public.negligence_analysis_history.review_status IS 'Human review workflow per client spec section 10: pending_review -> in_review -> approved (or rejected). Draft -> AI Analysis Complete is implicit in status=completed; this column governs everything after that.';
