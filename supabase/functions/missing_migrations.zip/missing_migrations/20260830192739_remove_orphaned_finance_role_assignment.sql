-- The only 'finance' row in access_role_assignments pointed to user_id
-- e11ccfe2-7442-4642-88fc-fc908d6a2000, which does not exist in auth.users,
-- profiles, or user_roles. It was dead data left over from a deleted/never-
-- completed account and meant nobody could ever actually be Finance staff.
-- Removing the stale row so a real Finance assignment can be made cleanly.
DELETE FROM access_role_assignments
WHERE id = 'de410f7a-cd44-4253-a16c-beb6f6eaf02b'
  AND user_id = 'e11ccfe2-7442-4642-88fc-fc908d6a2000'
  AND role_key = 'finance';
