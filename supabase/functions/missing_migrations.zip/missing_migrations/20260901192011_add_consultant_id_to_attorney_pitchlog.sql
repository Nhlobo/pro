ALTER TABLE public.attorney_pitchlog
  ADD COLUMN consultant_id uuid REFERENCES public.sales_consultants(id);

CREATE INDEX idx_attorney_pitchlog_consultant_id ON public.attorney_pitchlog(consultant_id);

-- Backfill: sales_person is stored as either a first name or a full name
-- (spot-checked: top values are first-name-only). All 13 active
-- sales_consultants have unique first names, so first-name matching is
-- unambiguous, not a guess.
UPDATE public.attorney_pitchlog ap
SET consultant_id = sc.id
FROM public.sales_consultants sc
WHERE ap.consultant_id IS NULL
  AND (
    lower(split_part(trim(sc.name), ' ', 1)) = lower(trim(ap.sales_person))
    OR lower(trim(sc.name)) = lower(trim(ap.sales_person))
  );
