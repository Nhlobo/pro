-- notifications
ALTER POLICY "Users can create their own notifications, staff can create any" ON public.notifications
WITH CHECK (((select auth.uid()) = user_id) OR is_admin_or_employee());

ALTER POLICY "Users can update their own notifications" ON public.notifications
USING ((select auth.uid()) = user_id);

ALTER POLICY "Users can view their own notifications" ON public.notifications
USING ((select auth.uid()) = user_id);

-- profiles
ALTER POLICY "Admins or self can insert profiles" ON public.profiles
WITH CHECK (is_strict_admin() OR ((select auth.uid()) = id));

ALTER POLICY "Company users can view relevant profiles" ON public.profiles
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((referring_attorney_id IS NOT NULL) AND (referring_attorney_id = get_current_user_referring_attorney()))
);

ALTER POLICY "Users can view own profile" ON public.profiles
USING ((select auth.uid()) = id);

ALTER POLICY "Users can update own profile" ON public.profiles
USING ((select auth.uid()) = id)
WITH CHECK (
  ((select auth.uid()) = id)
  AND (NOT (role IS DISTINCT FROM (SELECT profiles_1.role FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (user_type IS DISTINCT FROM (SELECT profiles_1.user_type FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (referring_attorney_id IS DISTINCT FROM (SELECT profiles_1.referring_attorney_id FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (expert_id IS DISTINCT FROM (SELECT profiles_1.expert_id FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (is_active IS DISTINCT FROM (SELECT profiles_1.is_active FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (deactivated_at IS DISTINCT FROM (SELECT profiles_1.deactivated_at FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (deactivated_by IS DISTINCT FROM (SELECT profiles_1.deactivated_by FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (deactivation_reason IS DISTINCT FROM (SELECT profiles_1.deactivation_reason FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (last_login_at IS DISTINCT FROM (SELECT profiles_1.last_login_at FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
  AND (NOT (is_external_portal_user IS DISTINCT FROM (SELECT profiles_1.is_external_portal_user FROM profiles profiles_1 WHERE (profiles_1.id = (select auth.uid())))))
);
