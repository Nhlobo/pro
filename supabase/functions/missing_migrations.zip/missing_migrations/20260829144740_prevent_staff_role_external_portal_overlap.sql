-- Database-level guard against the same problem the external-portal-auth
-- edge function now checks: an identity should never simultaneously
-- hold an internal admin/employee role and be flagged as an external
-- portal user, because every RLS policy in this system treats
-- admin/employee as "see everything, no scoping" — the combination
-- would silently grant full cross-firm visibility through a portal
-- login. This is a database trigger so it holds even if a future
-- change bypasses or predates the edge-function check.

CREATE OR REPLACE FUNCTION public.prevent_staff_portal_role_overlap()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_TABLE_NAME = 'profiles' THEN
    IF NEW.is_external_portal_user IS TRUE AND EXISTS (
      SELECT 1 FROM public.user_roles WHERE user_id = NEW.id AND role IN ('admin','employee')
    ) THEN
      RAISE EXCEPTION 'Cannot flag % as an external portal user: this account holds an internal admin/employee role', NEW.id;
    END IF;
  ELSIF TG_TABLE_NAME = 'user_roles' THEN
    IF NEW.role IN ('admin','employee') AND EXISTS (
      SELECT 1 FROM public.profiles WHERE id = NEW.user_id AND is_external_portal_user IS TRUE
    ) THEN
      RAISE EXCEPTION 'Cannot grant % to %: this account is an external portal user', NEW.role, NEW.user_id;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.prevent_staff_portal_role_overlap() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_prevent_staff_portal_overlap_profiles ON public.profiles;
CREATE TRIGGER trg_prevent_staff_portal_overlap_profiles
BEFORE INSERT OR UPDATE OF is_external_portal_user ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.prevent_staff_portal_role_overlap();

DROP TRIGGER IF EXISTS trg_prevent_staff_portal_overlap_roles ON public.user_roles;
CREATE TRIGGER trg_prevent_staff_portal_overlap_roles
BEFORE INSERT OR UPDATE OF role ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.prevent_staff_portal_role_overlap();
