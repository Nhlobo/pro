-- TRUNCATE is a table-wide operation that Postgres Row-Level Security
-- never governs, regardless of any RLS policy on the table. Every
-- table in the schema currently grants TRUNCATE to anon (fully
-- unauthenticated) and/or authenticated (any logged-in user, staff or
-- external portal). This is a Supabase default-on-table-creation
-- grant that was never revoked project-wide, not something specific
-- to the external portal work. No legitimate feature — public intake
-- form, portal read, or staff workflow — ever needs to truncate a
-- whole table, so this is safe to revoke everywhere without touching
-- any INSERT/UPDATE/DELETE/SELECT grant or any RLS policy.

DO $$
DECLARE
  t record;
BEGIN
  FOR t IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
  LOOP
    EXECUTE format('REVOKE TRUNCATE ON TABLE public.%I FROM anon, authenticated;', t.table_name);
  END LOOP;
END $$;
