-- idx_notifications_user_id is a strict prefix of idx_notifications_user_created
-- (user_id, created_at DESC) — any query plannable with the single-column index
-- is equally plannable with the composite one, so it's pure write-overhead bloat
-- on a 94k+ row, high-insert-volume table.
DROP INDEX IF EXISTS public.idx_notifications_user_id;
