-- anon (fully unauthenticated) currently holds SELECT/INSERT/UPDATE/
-- DELETE/TRUNCATE/TRIGGER/REFERENCES on all three tables, left over
-- from the abandoned JWT-claim design. SELECT/INSERT/UPDATE/DELETE are
-- blocked in practice by RLS having no matching policy for anon, but
-- TRUNCATE is a table-wide operation RLS never covers — anyone,
-- unauthenticated, could currently wipe these tables outright. Real
-- portal users are always `authenticated` (confirmed in the OTP/
-- access-link bridging code), so anon needs zero privileges here.

REVOKE ALL ON public.external_portal_cases FROM anon;
REVOKE ALL ON public.external_portal_case_documents FROM anon;
REVOKE ALL ON public.external_portal_case_events FROM anon;

-- Confirm RLS itself is enabled and forced (belt-and-braces — a table
-- owner or superuser role bypasses RLS unless FORCE is set, and this
-- schema has had ad-hoc superuser SQL run against it before).
ALTER TABLE public.external_portal_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.external_portal_case_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.external_portal_case_events ENABLE ROW LEVEL SECURITY;
