-- Add the denormalized display fields portal pages actually need, so
-- they can stop reading appointments/claimants/referring_attorneys/
-- medical_experts directly for case lists and case detail. Additive
-- only — no existing column touched.

ALTER TABLE public.external_portal_cases
  ADD COLUMN IF NOT EXISTS service_fee numeric,
  ADD COLUMN IF NOT EXISTS deposit_amount numeric,
  ADD COLUMN IF NOT EXISTS payment_status text,
  ADD COLUMN IF NOT EXISTS payment_date timestamptz,
  ADD COLUMN IF NOT EXISTS assessment_code text,
  ADD COLUMN IF NOT EXISTS claimant_auto_id text,
  ADD COLUMN IF NOT EXISTS claimant_contact_number text,
  ADD COLUMN IF NOT EXISTS referring_attorney_name text,
  ADD COLUMN IF NOT EXISTS referring_attorney_email text,
  ADD COLUMN IF NOT EXISTS referring_attorney_phone text,
  ADD COLUMN IF NOT EXISTS referring_attorney_contact_person text,
  ADD COLUMN IF NOT EXISTS expert_first_name text,
  ADD COLUMN IF NOT EXISTS expert_last_name text,
  ADD COLUMN IF NOT EXISTS expert_type text,
  ADD COLUMN IF NOT EXISTS expert_practice_address text;

CREATE OR REPLACE FUNCTION public.sync_external_portal_case()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_claimant record;
  v_attorney record;
  v_expert record;
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.external_portal_cases WHERE appointment_id = OLD.id;
    RETURN OLD;
  END IF;

  SELECT first_name, last_name, auto_id, contact_number INTO v_claimant
  FROM public.claimants WHERE id = NEW.claimant_id;

  SELECT name, email, phone, contact_person INTO v_attorney
  FROM public.referring_attorneys WHERE id = NEW.referring_attorney_id;

  SELECT first_name, last_name, expert_type, practice_address INTO v_expert
  FROM public.medical_experts WHERE id = NEW.expert_id;

  INSERT INTO public.external_portal_cases (
    appointment_id, claimant_id, referring_attorney_id,
    assigned_attorney_contact_id, expert_id, case_status, matter_type,
    appointment_date, claimant_first_name, claimant_last_name,
    deleted_at, updated_at,
    service_fee, deposit_amount, payment_status, payment_date, assessment_code,
    claimant_auto_id, claimant_contact_number,
    referring_attorney_name, referring_attorney_email, referring_attorney_phone,
    referring_attorney_contact_person,
    expert_first_name, expert_last_name, expert_type, expert_practice_address
  ) VALUES (
    NEW.id, NEW.claimant_id, NEW.referring_attorney_id,
    NEW.assigned_attorney_contact_id, NEW.expert_id, NEW.case_status,
    NEW.matter_type, NEW.appointment_date, v_claimant.first_name, v_claimant.last_name,
    NEW.deleted_at, now(),
    NEW.service_fee, NEW.deposit_amount, NEW.payment_status, NEW.payment_date, NEW.assessment_code,
    v_claimant.auto_id, v_claimant.contact_number,
    v_attorney.name, v_attorney.email, v_attorney.phone, v_attorney.contact_person,
    v_expert.first_name, v_expert.last_name, v_expert.expert_type, v_expert.practice_address
  )
  ON CONFLICT (appointment_id) DO UPDATE SET
    claimant_id = EXCLUDED.claimant_id,
    referring_attorney_id = EXCLUDED.referring_attorney_id,
    assigned_attorney_contact_id = EXCLUDED.assigned_attorney_contact_id,
    expert_id = EXCLUDED.expert_id,
    case_status = EXCLUDED.case_status,
    matter_type = EXCLUDED.matter_type,
    appointment_date = EXCLUDED.appointment_date,
    claimant_first_name = EXCLUDED.claimant_first_name,
    claimant_last_name = EXCLUDED.claimant_last_name,
    deleted_at = EXCLUDED.deleted_at,
    updated_at = now(),
    service_fee = EXCLUDED.service_fee,
    deposit_amount = EXCLUDED.deposit_amount,
    payment_status = EXCLUDED.payment_status,
    payment_date = EXCLUDED.payment_date,
    assessment_code = EXCLUDED.assessment_code,
    claimant_auto_id = EXCLUDED.claimant_auto_id,
    claimant_contact_number = EXCLUDED.claimant_contact_number,
    referring_attorney_name = EXCLUDED.referring_attorney_name,
    referring_attorney_email = EXCLUDED.referring_attorney_email,
    referring_attorney_phone = EXCLUDED.referring_attorney_phone,
    referring_attorney_contact_person = EXCLUDED.referring_attorney_contact_person,
    expert_first_name = EXCLUDED.expert_first_name,
    expert_last_name = EXCLUDED.expert_last_name,
    expert_type = EXCLUDED.expert_type,
    expert_practice_address = EXCLUDED.expert_practice_address;

  RETURN NEW;
END;
$$;

-- Also re-sync on claimant/attorney/expert detail edits, not just
-- appointment-column changes, since these are now denormalized here.
CREATE OR REPLACE FUNCTION public.sync_external_portal_case_from_claimant()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.external_portal_cases
  SET claimant_first_name = NEW.first_name,
      claimant_last_name = NEW.last_name,
      claimant_auto_id = NEW.auto_id,
      claimant_contact_number = NEW.contact_number,
      updated_at = now()
  WHERE claimant_id = NEW.id;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.sync_external_portal_case_from_claimant() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_sync_external_portal_case_from_claimant ON public.claimants;
CREATE TRIGGER trg_sync_external_portal_case_from_claimant
AFTER UPDATE OF first_name, last_name, auto_id, contact_number ON public.claimants
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_case_from_claimant();

CREATE OR REPLACE FUNCTION public.sync_external_portal_case_from_attorney()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.external_portal_cases
  SET referring_attorney_name = NEW.name,
      referring_attorney_email = NEW.email,
      referring_attorney_phone = NEW.phone,
      referring_attorney_contact_person = NEW.contact_person,
      updated_at = now()
  WHERE referring_attorney_id = NEW.id;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.sync_external_portal_case_from_attorney() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_sync_external_portal_case_from_attorney ON public.referring_attorneys;
CREATE TRIGGER trg_sync_external_portal_case_from_attorney
AFTER UPDATE OF name, email, phone, contact_person ON public.referring_attorneys
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_case_from_attorney();

CREATE OR REPLACE FUNCTION public.sync_external_portal_case_from_expert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.external_portal_cases
  SET expert_first_name = NEW.first_name,
      expert_last_name = NEW.last_name,
      expert_type = NEW.expert_type,
      expert_practice_address = NEW.practice_address,
      updated_at = now()
  WHERE expert_id = NEW.id;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.sync_external_portal_case_from_expert() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_sync_external_portal_case_from_expert ON public.medical_experts;
CREATE TRIGGER trg_sync_external_portal_case_from_expert
AFTER UPDATE OF first_name, last_name, expert_type, practice_address ON public.medical_experts
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_case_from_expert();

-- Also widen the appointments trigger to fire on the newly-mirrored
-- financial/assessment columns.
DROP TRIGGER IF EXISTS trg_sync_external_portal_case ON public.appointments;
CREATE TRIGGER trg_sync_external_portal_case
AFTER INSERT OR UPDATE OF claimant_id, referring_attorney_id, assigned_attorney_contact_id,
  expert_id, case_status, matter_type, appointment_date, deleted_at,
  service_fee, deposit_amount, payment_status, payment_date, assessment_code
OR DELETE ON public.appointments
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_case();

-- Re-backfill with the new columns populated
UPDATE public.external_portal_cases c
SET service_fee = a.service_fee,
    deposit_amount = a.deposit_amount,
    payment_status = a.payment_status,
    payment_date = a.payment_date,
    assessment_code = a.assessment_code,
    claimant_auto_id = cl.auto_id,
    claimant_contact_number = cl.contact_number,
    referring_attorney_name = ra.name,
    referring_attorney_email = ra.email,
    referring_attorney_phone = ra.phone,
    referring_attorney_contact_person = ra.contact_person,
    expert_first_name = me.first_name,
    expert_last_name = me.last_name,
    expert_type = me.expert_type,
    expert_practice_address = me.practice_address
FROM public.appointments a
LEFT JOIN public.claimants cl ON cl.id = a.claimant_id
LEFT JOIN public.referring_attorneys ra ON ra.id = a.referring_attorney_id
LEFT JOIN public.medical_experts me ON me.id = a.expert_id
WHERE c.appointment_id = a.id;
