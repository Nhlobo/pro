SELECT cron.schedule(
  'monthly-performance-snapshot',
  '10 6 25 * *',
  $$SELECT public.snapshot_monthly_performance();$$
);
