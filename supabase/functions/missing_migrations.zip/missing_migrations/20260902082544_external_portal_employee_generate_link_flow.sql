CREATE OR REPLACE FUNCTION public.external_portal_referring_attorneys_by_usage()
RETURNS TABLE (
  id UUID,
  name TEXT,
  contact_person TEXT,
  email TEXT,
  usage_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'employee')) THEN
    RAISE EXCEPTION 'Admin or employee privileges required';
  END IF;

  RETURN QUERY
  SELECT
    ra.id,
    ra.name,
    ra.contact_person,
    ra.email,
    count(a.id) AS usage_count
  FROM public.referring_attorneys ra
  LEFT JOIN public.appointments a
    ON a.referring_attorney_id = ra.id
    AND a.deleted_at IS NULL
    AND a.case_status IS DISTINCT FROM 'cancelled'
  GROUP BY ra.id, ra.name, ra.contact_person, ra.email
  ORDER BY usage_count DESC, ra.name ASC;
END;
$$;

CREATE OR REPLACE FUNCTION public.external_portal_medical_experts_by_usage()
RETURNS TABLE (
  id UUID,
  first_name TEXT,
  last_name TEXT,
  email TEXT,
  usage_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'employee')) THEN
    RAISE EXCEPTION 'Admin or employee privileges required';
  END IF;

  RETURN QUERY
  SELECT
    me.id,
    me.first_name,
    me.last_name,
    me.email,
    count(a.id) AS usage_count
  FROM public.medical_experts me
  LEFT JOIN public.appointments a
    ON a.expert_id = me.id
    AND a.deleted_at IS NULL
    AND a.case_status IS DISTINCT FROM 'cancelled'
  GROUP BY me.id, me.first_name, me.last_name, me.email
  ORDER BY usage_count DESC, me.last_name ASC, me.first_name ASC;
END;
$$;

CREATE OR REPLACE FUNCTION public.external_portal_attorney_contacts_by_usage(p_referring_attorney_id uuid)
RETURNS TABLE (
  id UUID,
  referring_attorney_id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  is_active BOOLEAN,
  usage_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'employee')) THEN
    RAISE EXCEPTION 'Admin or employee privileges required';
  END IF;

  RETURN QUERY
  SELECT
    rac.id,
    rac.referring_attorney_id,
    rac.full_name,
    rac.email,
    rac.phone,
    rac.is_active,
    count(a.id) AS usage_count
  FROM public.referring_attorney_contacts rac
  LEFT JOIN public.appointments a
    ON a.assigned_attorney_contact_id = rac.id
    AND a.deleted_at IS NULL
    AND a.case_status IS DISTINCT FROM 'cancelled'
  WHERE rac.referring_attorney_id = p_referring_attorney_id
    AND rac.is_active = true
  GROUP BY rac.id, rac.referring_attorney_id, rac.full_name, rac.email, rac.phone, rac.is_active
  ORDER BY usage_count DESC, rac.full_name ASC;
END;
$$;

CREATE OR REPLACE FUNCTION public.external_portal_update_account_scope(
  _account_id UUID,
  _scope public.external_portal_account_scope
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'employee')) THEN
    RAISE EXCEPTION 'Admin or employee privileges required';
  END IF;

  UPDATE public.external_portal_accounts
  SET
    account_scope = _scope,
    assigned_attorney_contact_id = CASE WHEN _scope = 'firm' THEN NULL ELSE assigned_attorney_contact_id END
  WHERE id = _account_id
    AND portal_type = 'attorney';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'External portal attorney account % not found', _account_id;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.external_portal_update_account_contact(
  _account_id UUID,
  _contact_id UUID
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'employee')) THEN
    RAISE EXCEPTION 'Admin or employee privileges required';
  END IF;

  UPDATE public.external_portal_accounts
  SET assigned_attorney_contact_id = _contact_id
  WHERE id = _account_id
    AND portal_type = 'attorney';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'External portal attorney account % not found', _account_id;
  END IF;
END;
$$;

DO $$ BEGIN
  CREATE POLICY "Employees can view external portal account emails"
    ON public.external_portal_account_emails FOR SELECT
    USING (public.has_role(auth.uid(), 'employee'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
