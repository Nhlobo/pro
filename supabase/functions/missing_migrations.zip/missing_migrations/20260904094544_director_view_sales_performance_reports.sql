-- /admin/sales-performance is an eligible, default-on module for the
-- director role, but sales_performance_reports had no SELECT policy for
-- director at all (only admin, or the consultant viewing their own row).
-- The page's whole data source is an unfiltered `select('*')` expecting
-- every consultant's reports -- for director this silently came back
-- empty (RLS filters everything, no error), so the page loaded with a
-- blank table instead of the team's performance data.
CREATE POLICY "Director can view all sales performance reports"
ON public.sales_performance_reports
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'director'::app_role));
