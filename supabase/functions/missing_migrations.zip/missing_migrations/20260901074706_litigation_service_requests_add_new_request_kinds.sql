-- Document the full set of valid service_type values now that Addendum
-- and Affidavit requests (previously wrongly funnelled through
-- appointment_requests) are routed into this table too. No CHECK
-- constraint exists on service_type (free text), so this is metadata only.
COMMENT ON COLUMN public.litigation_service_requests.service_type IS
  'One of: bundle_preparation, report_summary, trial_coordination, joint_minutes, court_formatting, addendum, affidavit. Free text column (no CHECK constraint) — keep frontend/admin label maps in sync when adding new values.';
