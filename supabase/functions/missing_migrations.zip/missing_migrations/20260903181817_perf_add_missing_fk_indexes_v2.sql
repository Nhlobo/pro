-- Covering indexes for FKs the performance advisor flagged as unindexed.
-- (The two "law_firm_id"-named constraints on claimants/profiles actually
-- point at referring_attorney_id, not a literal law_firm_id column —
-- confirmed against pg_constraint before writing this.)

CREATE INDEX IF NOT EXISTS idx_appointments_deleted_by ON public.appointments (deleted_by);

-- claimants.referring_attorney_id has two FK constraints
-- (claimants_law_firm_id_fkey and fk_claimants_law_firm) — one index covers both,
-- and it's also the column most RLS policies on claimants filter on.
CREATE INDEX IF NOT EXISTS idx_claimants_referring_attorney_id ON public.claimants (referring_attorney_id);

CREATE INDEX IF NOT EXISTS idx_profiles_attorney_contact_id ON public.profiles (attorney_contact_id);
CREATE INDEX IF NOT EXISTS idx_profiles_deactivated_by ON public.profiles (deactivated_by);
CREATE INDEX IF NOT EXISTS idx_profiles_expert_id ON public.profiles (expert_id);
CREATE INDEX IF NOT EXISTS idx_profiles_referring_attorney_id ON public.profiles (referring_attorney_id);
