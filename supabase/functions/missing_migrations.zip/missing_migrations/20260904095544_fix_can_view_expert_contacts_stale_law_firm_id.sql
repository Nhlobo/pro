-- can_view_expert_contacts() still referenced appointments.law_firm_id (that
-- column was renamed to referring_attorney_id back in migration
-- 20251031125204) and called get_current_user_law_firm(), a function that
-- no longer exists at all. get_medical_experts_secure() -- the RPC the
-- Expert Payment Planner calls to list experts -- runs this function for
-- any user who isn't admin/employee (admin/employee short-circuit past it
-- in the CASE statement, which is why this never surfaced for Admin).
-- For finance/director it threw "column law_firm_id does not exist" and
-- broke expert loading on that page.
CREATE OR REPLACE FUNCTION public.can_view_expert_contacts(expert_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  -- Admin users can see all contact details
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) OR
  -- Users can see contact details ONLY for experts they have active appointments with
  EXISTS (
    SELECT 1 FROM public.appointments
    WHERE expert_id = $1
    AND referring_attorney_id = public.get_current_user_referring_attorney()
    AND case_status IN ('scheduled', 'in_progress', 'completed')
  );
$function$;
