ALTER TABLE public.password_reset_requests ADD COLUMN error_message text;
