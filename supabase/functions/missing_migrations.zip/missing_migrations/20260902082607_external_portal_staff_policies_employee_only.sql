DROP POLICY IF EXISTS "external_portal_accounts_staff_select" ON public.external_portal_accounts;
CREATE POLICY "external_portal_accounts_staff_select"
  ON public.external_portal_accounts FOR SELECT
  USING (public.has_role(auth.uid(), 'employee'::app_role));

DROP POLICY IF EXISTS "external_portal_accounts_staff_insert" ON public.external_portal_accounts;
CREATE POLICY "external_portal_accounts_staff_insert"
  ON public.external_portal_accounts FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'employee'::app_role));

DROP POLICY IF EXISTS "external_portal_access_links_staff_select" ON public.external_portal_access_links;
CREATE POLICY "external_portal_access_links_staff_select"
  ON public.external_portal_access_links FOR SELECT
  USING (public.has_role(auth.uid(), 'employee'::app_role));
