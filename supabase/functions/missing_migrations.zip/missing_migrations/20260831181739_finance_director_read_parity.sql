-- Finance / Director read parity on the Admin Finance & Payments page.
-- finance/director were added to app_role but never granted SELECT
-- policies on the tables /admin/finance depends on (only admin/employee
-- were, via has_role/is_system_admin). Additive, SELECT-only policies,
-- mirroring the existing sales_consultant pattern. Nothing existing is
-- dropped or narrowed; is_system_admin() itself is untouched.

CREATE POLICY "Finance and director can view all AOD documents"
ON public.aod_documents
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);

CREATE POLICY "Finance and director can view all AOD payments"
ON public.aod_payments
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);

CREATE POLICY "Finance and director can view all short term agreements"
ON public.short_term_agreements
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);

CREATE POLICY "Finance and director can view all short term agreement payments"
ON public.short_term_agreement_payments
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);

CREATE POLICY "Finance and director can view all appointments for debt management"
ON public.appointments
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);

CREATE POLICY "Finance and director can view all claimants"
ON public.claimants
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);

CREATE POLICY "Finance and director can view all law firms"
ON public.referring_attorneys
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);
