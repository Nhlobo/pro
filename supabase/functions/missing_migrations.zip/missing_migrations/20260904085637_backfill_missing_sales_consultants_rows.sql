-- Backfill: create the missing sales_consultants row for any account that
-- was set up as a Sales Consultant before create-user/index.ts created one
-- automatically (see that file's 2026-09-04 change). Until now, creating a
-- brand-new account directly with role sales_consultant never inserted a
-- sales_consultants row at all -- a working login, but no row for
-- useSalesIncentives ("My Sales Dashboard") or useSalesConsultantStats (the
-- "Welcome back" card on the home dashboard) to find via
-- sales_consultants.user_id = auth.uid().
--
-- This checks all three places a "this account is a Sales Consultant"
-- signal can live -- profiles.role, user_roles, and access_role_assignments
-- -- since a comment elsewhere in this codebase notes these have drifted
-- apart on real accounts before. Anyone flagged as sales_consultant in any
-- of the three, who doesn't already have a sales_consultants row, gets one
-- created here. Fully additive: never touches an existing row, and
-- ON CONFLICT (user_id) DO NOTHING makes it safe to run more than once.

INSERT INTO public.sales_consultants (user_id, name, type, is_active)
SELECT
  p.id,
  COALESCE(
    NULLIF(TRIM(COALESCE(p.first_name, '') || ' ' || COALESCE(p.last_name, '')), ''),
    p.email,
    'Sales Consultant'
  ),
  'internal',
  true
FROM public.profiles p
WHERE (
  p.role = 'sales_consultant'
  OR EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = p.id AND ur.role = 'sales_consultant'
  )
  OR EXISTS (
    SELECT 1 FROM public.access_role_assignments ara
    WHERE ara.user_id = p.id AND ara.role_key = 'sales_consultant'
  )
)
AND NOT EXISTS (
  SELECT 1 FROM public.sales_consultants sc WHERE sc.user_id = p.id
)
ON CONFLICT (user_id) DO NOTHING;
