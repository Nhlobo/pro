-- worksof28@gmail.com (b4b256d5-4ef5-4b52-b5bb-fa660962259d) was confirmed
-- to be a test account (raw_user_meta_data.first_name = 'testingdirector')
-- with no real case/attorney/portal data attached (0 rows in
-- referring_attorneys, attorneys, external_portal_accounts). It had
-- conflicting roles: user_roles held BOTH 'director' and
-- 'referring_attorney' for the same id, and profiles/access_role_assignments
-- disagreed with each other. Removing entirely per confirmed instruction.
-- audit_logs rows are left intact as historical record.

DELETE FROM access_role_assignments WHERE user_id = 'b4b256d5-4ef5-4b52-b5bb-fa660962259d';
DELETE FROM user_roles WHERE user_id = 'b4b256d5-4ef5-4b52-b5bb-fa660962259d';
DELETE FROM profiles WHERE id = 'b4b256d5-4ef5-4b52-b5bb-fa660962259d';
