-- Same stale-rename issue: appointment_requests.law_firm_id,
-- claimants.law_firm_id, and appointments.law_firm_id were all renamed to
-- referring_attorney_id. Not currently invoked from the frontend (no UI
-- calls this RPC), but fixing it now rather than leaving another landmine.
CREATE OR REPLACE FUNCTION public.sync_existing_appointment_requests()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  req_record RECORD;
  claimant_record RECORD;
  expert_record RECORD;
  appointment_record RECORD;
  appointment_datetime timestamp with time zone;
BEGIN
  FOR req_record IN
    SELECT * FROM appointment_requests
    WHERE status IN ('approved', 'new_date_proposed')
    AND synced_appointment_id IS NULL
  LOOP
    BEGIN
      IF req_record.status = 'approved' AND req_record.confirmed_appointment_date IS NOT NULL THEN
        appointment_datetime = req_record.confirmed_appointment_date;
      ELSIF req_record.status = 'new_date_proposed' AND req_record.suggested_date IS NOT NULL THEN
        IF req_record.suggested_date ~ '^\d{4}-\d{2}-\d{2}T' THEN
          appointment_datetime = req_record.suggested_date::timestamp with time zone;
        ELSE
          appointment_datetime = (req_record.suggested_date || ' 09:00:00')::timestamp with time zone;
        END IF;
      ELSE
        IF req_record.suggested_date IS NOT NULL THEN
          appointment_datetime = (req_record.suggested_date || ' 09:00:00')::timestamp with time zone;
        ELSE
          CONTINUE;
        END IF;
      END IF;

      SELECT * INTO claimant_record
      FROM claimants
      WHERE referring_attorney_id = req_record.referring_attorney_id
      AND first_name ILIKE req_record.claimant_first_name
      AND last_name ILIKE req_record.claimant_last_name
      LIMIT 1;

      IF claimant_record IS NULL THEN
        INSERT INTO claimants (
          referring_attorney_id,
          first_name,
          last_name,
          auto_id
        ) VALUES (
          req_record.referring_attorney_id,
          req_record.claimant_first_name,
          req_record.claimant_last_name,
          'AR-' || EXTRACT(YEAR FROM NOW()) || '-' || LPAD(nextval('claimants_auto_id_seq')::text, 6, '0')
        ) RETURNING * INTO claimant_record;
      END IF;

      SELECT * INTO expert_record
      FROM medical_experts
      WHERE expert_type = req_record.expert_type_requested
      AND province = req_record.province
      AND status = 'active'
      LIMIT 1;

      IF expert_record IS NULL THEN
        SELECT * INTO expert_record
        FROM medical_experts
        WHERE expert_type = req_record.expert_type_requested
        AND status = 'active'
        LIMIT 1;
      END IF;

      IF expert_record IS NULL THEN
        RAISE NOTICE 'No expert found for request % with type %', req_record.id, req_record.expert_type_requested;
        CONTINUE;
      END IF;

      INSERT INTO appointments (
        claimant_id,
        expert_id,
        appointment_date,
        referring_attorney,
        referring_attorney_id,
        case_status,
        matter_type,
        deposit_amount
      ) VALUES (
        claimant_record.id,
        expert_record.id,
        appointment_datetime,
        req_record.referring_attorney_name,
        req_record.referring_attorney_id,
        'scheduled',
        req_record.matter_type,
        0
      ) RETURNING * INTO appointment_record;

      UPDATE appointment_requests
      SET synced_appointment_id = appointment_record.id
      WHERE id = req_record.id;

      RAISE NOTICE 'Synced appointment request % to appointment %', req_record.id, appointment_record.id;

    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Error syncing appointment request %: %', req_record.id, SQLERRM;
      CONTINUE;
    END;
  END LOOP;

  RAISE NOTICE 'Completed syncing existing appointment requests';
END;
$function$;
