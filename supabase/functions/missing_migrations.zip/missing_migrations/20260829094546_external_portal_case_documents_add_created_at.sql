ALTER TABLE public.external_portal_case_documents
  ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE OR REPLACE FUNCTION public.sync_external_portal_case_document()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.external_portal_case_documents WHERE document_id = OLD.id;
    RETURN OLD;
  END IF;

  IF NEW.appointment_id IS NULL THEN
    DELETE FROM public.external_portal_case_documents WHERE document_id = NEW.id;
    RETURN NEW;
  END IF;

  INSERT INTO public.external_portal_case_documents (
    appointment_id, document_id, document_type, file_name, file_path,
    upload_date, upload_time, is_visible_to_attorney, is_visible_to_expert, created_at
  ) VALUES (
    NEW.appointment_id, NEW.id, NEW.document_type, NEW.file_name, NEW.file_path,
    NEW.upload_date, NEW.upload_time,
    COALESCE(NEW.is_visible_to_attorney, true), COALESCE(NEW.is_visible_to_expert, true), NEW.created_at
  )
  ON CONFLICT (document_id) DO UPDATE SET
    appointment_id = EXCLUDED.appointment_id,
    document_type = EXCLUDED.document_type,
    file_name = EXCLUDED.file_name,
    file_path = EXCLUDED.file_path,
    upload_date = EXCLUDED.upload_date,
    upload_time = EXCLUDED.upload_time,
    is_visible_to_attorney = EXCLUDED.is_visible_to_attorney,
    is_visible_to_expert = EXCLUDED.is_visible_to_expert,
    created_at = EXCLUDED.created_at;

  RETURN NEW;
END;
$$;

UPDATE public.external_portal_case_documents ecd
SET created_at = d.created_at
FROM public.documents d
WHERE ecd.document_id = d.id;
