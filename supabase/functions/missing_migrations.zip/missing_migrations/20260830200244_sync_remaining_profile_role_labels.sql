-- Ezrah and Nkosi both correctly resolve to sales_consultant everywhere
-- that matters (user_roles + access_role_assignments), but their profile
-- display fields still said role='user', user_type='employee' -- cosmetic
-- drift from before this was ever standardized. Syncing for consistency.
UPDATE profiles SET role = 'sales_consultant', user_type = 'user'
WHERE id IN ('3eaa3ca7-968b-4014-8102-65fc8e578037', 'f36b7d35-2048-4993-8f9b-46bfe4a36fc3');
