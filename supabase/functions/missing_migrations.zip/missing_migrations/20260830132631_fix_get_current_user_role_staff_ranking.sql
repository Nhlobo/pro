-- SECURITY FIX: get_current_user_role() ranked 'referring_attorney' (3)
-- above every internal staff role except admin/employee, because
-- sales_consultant/finance/director all fell into the ELSE=4 bucket.
-- Any staff member holding BOTH a legitimate staff role and a
-- referring_attorney/medical_expert row (e.g. injected by the external
-- portal bridge, see the accompanying edge-function fix) was therefore
-- resolved as an external portal user instead of staff on login routing
-- and anywhere else this function is consulted.
--
-- Fix: rank every internal staff role above every external-portal role,
-- explicitly, so this can't regress silently if a new role is ever added.
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS text
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT role::TEXT
  FROM public.user_roles
  WHERE user_id = auth.uid()
  ORDER BY
    CASE role
      WHEN 'admin' THEN 1
      WHEN 'employee' THEN 2
      WHEN 'sales_consultant' THEN 3
      WHEN 'finance' THEN 4
      WHEN 'director' THEN 5
      WHEN 'referring_attorney' THEN 6
      WHEN 'medical_expert' THEN 7
      ELSE 8
    END
  LIMIT 1;
$function$;

COMMENT ON FUNCTION public.get_current_user_role() IS
  'Returns the highest-priority role for the current user. All internal staff roles (admin, employee, sales_consultant, finance, director) always outrank external-portal roles (referring_attorney, medical_expert), so an account that ends up holding both a staff role and an external-portal role (e.g. via a mis-provisioned external portal login) is still resolved as staff. Fixed 2026-08-30 after finance staff was mis-routed to the External Portal.';
