-- These policies are 100% redundant: each table already has a `{public}`-role
-- ALL policy with the identical predicate (is_system_admin()), which already
-- covers the `{authenticated}` role. Dropping the authenticated-only
-- duplicates removes duplicate policy evaluation on every query with zero
-- change in who can access what.

DROP POLICY "System admins bypass for appointments" ON public.appointments;
DROP POLICY "System admins full access to appointments" ON public.appointments;

DROP POLICY "System admins bypass for claimants" ON public.claimants;
DROP POLICY "System admins full access to claimants" ON public.claimants;

DROP POLICY "System admins bypass for law_firms" ON public.referring_attorneys;
DROP POLICY "System admins full access to law firms" ON public.referring_attorneys;

DROP POLICY "System admins bypass for expert_reports" ON public.expert_reports;
DROP POLICY "System admins full access to expert reports" ON public.expert_reports;
