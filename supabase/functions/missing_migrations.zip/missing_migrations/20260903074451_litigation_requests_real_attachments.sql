-- =====================================================================
-- Litigation Service Requests — parity fixes (2 of 3): real attachments
--
-- The admin page's attach/download UI was a local-only preview
-- (URL.createObjectURL, gone on refresh) — nothing was persisted, no
-- column existed for it, and no bucket existed for it. This adds the
-- storage + schema needed to make it real, and mirrors it through to
-- external_portal_litigation_requests so the requesting attorney can
-- see (and download) the response document too.
-- =====================================================================

ALTER TABLE public.litigation_service_requests
  ADD COLUMN response_document_path text,
  ADD COLUMN response_document_name text,
  ADD COLUMN response_document_uploaded_at timestamptz,
  ADD COLUMN response_document_uploaded_by uuid REFERENCES auth.users(id);

ALTER TABLE public.external_portal_litigation_requests
  ADD COLUMN response_document_path text,
  ADD COLUMN response_document_name text,
  ADD COLUMN response_document_uploaded_at timestamptz;

-- Storage bucket for these documents. Private, like every other
-- document bucket in this project (aod-documents, attorney-documents,
-- etc.) — access is via RLS + signed URLs, never public.
INSERT INTO storage.buckets (id, name, public)
VALUES ('litigation-service-documents', 'litigation-service-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Objects are stored as `<request_id>/<filename>` so ownership can be
-- checked by joining the folder name back to the request row, the same
-- ownership rule already enforced on the table itself (staff, the
-- requester, or their scoped referring-attorney account).
CREATE POLICY "Staff manage litigation request documents"
ON storage.objects FOR ALL
TO authenticated
USING (bucket_id = 'litigation-service-documents' AND is_admin_or_employee())
WITH CHECK (bucket_id = 'litigation-service-documents' AND is_admin_or_employee());

CREATE POLICY "Requesters view their own litigation request documents"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'litigation-service-documents'
  AND EXISTS (
    SELECT 1 FROM public.litigation_service_requests lsr
    WHERE lsr.id::text = (storage.foldername(storage.objects.name))[1]
      AND (
        lsr.requested_by = auth.uid()
        OR (
          NOT COALESCE((SELECT p.is_external_portal_user FROM public.profiles p WHERE p.id = auth.uid()), false)
          AND lsr.referring_attorney_id = get_current_user_referring_attorney()
        )
        OR (
          get_current_user_portal_account_scope() = 'firm'
          AND lsr.referring_attorney_id = get_current_user_referring_attorney()
        )
      )
  )
);

-- Extend the mirror sync to carry the response document fields through,
-- and widen the UPDATE OF trigger column list to fire on them.
CREATE OR REPLACE FUNCTION public.sync_external_portal_litigation_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.external_portal_litigation_requests WHERE id = OLD.id;
    RETURN OLD;
  END IF;
  INSERT INTO public.external_portal_litigation_requests (
    id, service_type, claimant_name, case_reference, urgency, status, description,
    requested_by, referring_attorney_id, requested_at, completed_at,
    response_document_path, response_document_name, response_document_uploaded_at
  ) VALUES (
    NEW.id, NEW.service_type, NEW.claimant_name, NEW.case_reference, NEW.urgency, NEW.status, NEW.description,
    NEW.requested_by, NEW.referring_attorney_id, NEW.requested_at, NEW.completed_at,
    NEW.response_document_path, NEW.response_document_name, NEW.response_document_uploaded_at
  )
  ON CONFLICT (id) DO UPDATE SET
    service_type = EXCLUDED.service_type, claimant_name = EXCLUDED.claimant_name,
    case_reference = EXCLUDED.case_reference, urgency = EXCLUDED.urgency, status = EXCLUDED.status,
    description = EXCLUDED.description, requested_by = EXCLUDED.requested_by,
    referring_attorney_id = EXCLUDED.referring_attorney_id, requested_at = EXCLUDED.requested_at,
    completed_at = EXCLUDED.completed_at,
    response_document_path = EXCLUDED.response_document_path,
    response_document_name = EXCLUDED.response_document_name,
    response_document_uploaded_at = EXCLUDED.response_document_uploaded_at;
  RETURN NEW;
END; $function$;

DROP TRIGGER IF EXISTS trg_sync_external_portal_litigation_request ON public.litigation_service_requests;
CREATE TRIGGER trg_sync_external_portal_litigation_request
AFTER INSERT OR DELETE OR UPDATE OF
  service_type, claimant_name, case_reference, urgency, status, description,
  requested_by, referring_attorney_id, completed_at,
  response_document_path, response_document_name, response_document_uploaded_at
ON public.litigation_service_requests
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_litigation_request();
