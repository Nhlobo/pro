-- TRUNCATE bypasses RLS entirely in Postgres, so leaving it granted to
-- authenticated would let any logged-in portal user wipe every firm's
-- mirrored case data at once, regardless of the SELECT-scoping RLS
-- policies. TRIGGER/REFERENCES are also unnecessary for a read-only
-- portal role. Revoking all three; SELECT stays.

REVOKE TRUNCATE, TRIGGER, REFERENCES ON public.external_portal_cases FROM authenticated;
REVOKE TRUNCATE, TRIGGER, REFERENCES ON public.external_portal_case_documents FROM authenticated;
REVOKE TRUNCATE, TRIGGER, REFERENCES ON public.external_portal_case_events FROM authenticated;
