CREATE TABLE public.expert_private_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  expert_id uuid NOT NULL REFERENCES public.medical_experts(id) ON DELETE CASCADE,
  title text NOT NULL,
  client_name text,
  session_date date NOT NULL,
  start_time time,
  end_time time,
  location text,
  fee numeric DEFAULT 0,
  paid boolean NOT NULL DEFAULT false,
  notes text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.expert_private_sessions TO authenticated;
GRANT ALL ON public.expert_private_sessions TO service_role;

ALTER TABLE public.expert_private_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Experts manage own private sessions"
ON public.expert_private_sessions FOR ALL TO authenticated
USING (expert_id = (SELECT p.expert_id FROM public.profiles p WHERE p.id = auth.uid()))
WITH CHECK (expert_id = (SELECT p.expert_id FROM public.profiles p WHERE p.id = auth.uid()));

CREATE INDEX idx_expert_private_sessions_expert_date ON public.expert_private_sessions(expert_id, session_date);

CREATE TRIGGER trg_expert_private_sessions_updated_at
BEFORE UPDATE ON public.expert_private_sessions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Experts can view their own payments"
ON public.expert_payments FOR SELECT TO authenticated
USING (expert_id = (SELECT p.expert_id FROM public.profiles p WHERE p.id = auth.uid()));
