-- Full backup of every table being wiped in the account/history reset,
-- taken immediately before deletion, so this is undoable. Schema
-- captured via CREATE TABLE ... AS SELECT * (structure + data both
-- preserved). Case-mirror tables (external_portal_cases etc.) are
-- untouched by this reset and therefore not backed up here.

CREATE TABLE public._backup_20260829_external_portal_accounts AS SELECT * FROM public.external_portal_accounts;
CREATE TABLE public._backup_20260829_external_portal_access_links AS SELECT * FROM public.external_portal_access_links;
CREATE TABLE public._backup_20260829_external_portal_account_access AS SELECT * FROM public.external_portal_account_access;
CREATE TABLE public._backup_20260829_external_portal_account_emails AS SELECT * FROM public.external_portal_account_emails;
CREATE TABLE public._backup_20260829_external_portal_audit_logs AS SELECT * FROM public.external_portal_audit_logs;
CREATE TABLE public._backup_20260829_external_portal_login_history AS SELECT * FROM public.external_portal_login_history;
CREATE TABLE public._backup_20260829_external_portal_messages AS SELECT * FROM public.external_portal_messages;
CREATE TABLE public._backup_20260829_external_portal_notifications AS SELECT * FROM public.external_portal_notifications;
CREATE TABLE public._backup_20260829_external_portal_otp_codes AS SELECT * FROM public.external_portal_otp_codes;
CREATE TABLE public._backup_20260829_external_portal_sessions AS SELECT * FROM public.external_portal_sessions;
CREATE TABLE public._backup_20260829_attorney_access_codes AS SELECT * FROM public.attorney_access_codes;
CREATE TABLE public._backup_20260829_expert_access_codes AS SELECT * FROM public.expert_access_codes;
CREATE TABLE public._backup_20260829_profiles_portal_flags AS
  SELECT id, is_external_portal_user, referring_attorney_id, attorney_contact_id, expert_id, role
  FROM public.profiles WHERE is_external_portal_user = true;

-- Lock these down immediately — backups of account/session data should
-- never be reachable through the API, only through direct DB access.
REVOKE ALL ON public._backup_20260829_external_portal_accounts FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_access_links FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_account_access FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_account_emails FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_audit_logs FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_login_history FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_messages FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_notifications FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_otp_codes FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_external_portal_sessions FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_attorney_access_codes FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_expert_access_codes FROM anon, authenticated;
REVOKE ALL ON public._backup_20260829_profiles_portal_flags FROM anon, authenticated;
