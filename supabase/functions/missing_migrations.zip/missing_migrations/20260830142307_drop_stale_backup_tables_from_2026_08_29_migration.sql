-- These 13 tables were temporary safety backups taken during the 2026-08-29
-- external portal Phase 2 migration (old access-code system -> new
-- account+OTP system) and the profiles portal-flags consolidation. Verified
-- safe to drop before removal:
--   * Zero references anywhere in the application code.
--   * No foreign keys point into any of them.
--   * Timestamp ranges show a clean, non-destructive cutover: e.g.
--     external_portal_audit_logs backup data ends 2026-08-29 16:02 and the
--     live table's data begins 2026-08-30 06:17 -- a deliberate archive-then-
--     reset boundary, not accidental data loss.
--   * attorney_access_codes / expert_access_codes were fully superseded by
--     external_portal_accounts / external_portal_access_links (this is
--     exactly why those two live tables are now empty -- the old code-based
--     system was retired, not broken).
-- All 13 had RLS disabled, making them fully readable/writable by the public
-- anon key. Dropping removes that exposure entirely rather than trying to
-- retrofit policies onto data nothing needs anymore.
DROP TABLE IF EXISTS public._backup_20260829_external_portal_accounts;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_access_links;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_account_access;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_account_emails;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_audit_logs;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_login_history;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_messages;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_notifications;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_otp_codes;
DROP TABLE IF EXISTS public._backup_20260829_external_portal_sessions;
DROP TABLE IF EXISTS public._backup_20260829_attorney_access_codes;
DROP TABLE IF EXISTS public._backup_20260829_expert_access_codes;
DROP TABLE IF EXISTS public._backup_20260829_profiles_portal_flags;
