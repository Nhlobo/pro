-- Full reset of external portal accounts, login history, and access
-- codes, per explicit request. Backed up immediately beforehand into
-- _backup_20260829_* tables. Case-mirror data (external_portal_cases
-- etc.) is untouched — it's fed by triggers off appointments directly
-- and has nothing to do with account/login state.

DELETE FROM public.external_portal_audit_logs;
DELETE FROM public.external_portal_login_history;
DELETE FROM public.external_portal_messages;
DELETE FROM public.external_portal_notifications;
DELETE FROM public.external_portal_otp_codes;
DELETE FROM public.external_portal_sessions;
DELETE FROM public.external_portal_account_access;
DELETE FROM public.external_portal_account_emails;
DELETE FROM public.external_portal_access_links;
DELETE FROM public.external_portal_accounts;
DELETE FROM public.attorney_access_codes;
DELETE FROM public.expert_access_codes;

-- Un-flag the profiles that were tied to those accounts, so they
-- revert to ordinary (non-portal) profiles rather than being
-- orphaned portal identities with no account behind them.
UPDATE public.profiles
SET is_external_portal_user = false,
    referring_attorney_id = NULL,
    attorney_contact_id = NULL,
    expert_id = NULL
WHERE is_external_portal_user = true;
