ALTER POLICY "epp_claimants_select" ON public.epp_claimants USING (epp_can_view((select auth.uid())));
ALTER POLICY "epp_claimants_insert" ON public.epp_claimants WITH CHECK (epp_can_manage((select auth.uid())));
ALTER POLICY "epp_claimants_update" ON public.epp_claimants USING (epp_can_manage((select auth.uid())));
ALTER POLICY "epp_claimants_delete" ON public.epp_claimants USING (epp_can_manage((select auth.uid())));
