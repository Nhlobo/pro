-- These SECURITY DEFINER functions are staff/role-management RPCs from the
-- newer "new_access" system. Verified before touching:
--   1. None of them are referenced inside any RLS policy (checked pg_policies
--      qual/with_check across every table) — unlike has_role()/is_system_admin(),
--      which ARE called inside dozens of {public}-role policies and must stay
--      anon-executable or every anonymous-facing query on those tables would
--      error out. Those two are deliberately left untouched.
--   2. None of them are called anywhere in the current frontend (only appear
--      in the generated types.ts) — this system isn't wired up to the UI yet.
--   3. change_staff_access_role's own body already checks auth.uid() IS NULL
--      and raises before doing anything, so this isn't fixing an active hole —
--      it's removing exposure that serves no purpose today.
-- Revoking anon (and, for the two trigger functions, also public) EXECUTE is
-- therefore a pure hardening step with no functional impact.

REVOKE EXECUTE ON FUNCTION public.change_staff_access_role(uuid, text, text, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.clear_access_reauth_flag() FROM anon;
REVOKE EXECUTE ON FUNCTION public.external_portal_staff_send_message(uuid, uuid, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_access_session_state() FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_new_staff_access_directory() FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_staff_module_access(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.new_access_has_module(uuid, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.new_access_is_admin(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.new_access_role_position_allowed(text, text) FROM anon;

-- Trigger functions are never meant to be called directly by any client role.
REVOKE EXECUTE ON FUNCTION public.notify_staff_new_litigation_request() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_new_access_updated_at() FROM anon, authenticated;
