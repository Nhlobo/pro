-- Seed the internal invoice sending pause flag (idempotent).
-- internal-invoice-delivery-processor checks this before claiming any
-- batch/single_test work; get_pdf (read-only, used for on-demand
-- download/view) is intentionally unaffected.
insert into public.system_settings (setting_key, setting_value, category, description)
values (
  'internal_invoice_sending_paused',
  'false'::jsonb,
  'internal_invoicing',
  'When true, internal-invoice-delivery-processor skips claiming new internal_invoice_delivery_queue work, so no internal invoice emails go out. Toggled from the Internal Invoices admin tab (Finance).'
)
on conflict (setting_key) do nothing;

-- Admins can already manage all of system_settings via the existing
-- "Admins can manage system settings" policy. Finance and director
-- staff need to toggle *this one* setting from the UI without being
-- granted admin's full read/write over every setting, so this policy
-- is scoped to just this setting_key.
create policy "Finance and director can toggle internal invoice pause"
on public.system_settings
for update
to authenticated
using (
  setting_key = 'internal_invoice_sending_paused'
  and (has_role(auth.uid(), 'finance'::app_role) or has_role(auth.uid(), 'director'::app_role))
)
with check (
  setting_key = 'internal_invoice_sending_paused'
  and (has_role(auth.uid(), 'finance'::app_role) or has_role(auth.uid(), 'director'::app_role))
);
