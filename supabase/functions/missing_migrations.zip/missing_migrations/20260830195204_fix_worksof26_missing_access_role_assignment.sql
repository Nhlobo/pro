-- worksof26@gmail.com (87c4ff72-d104-4f4c-b9af-c463e7e391b4) has role
-- 'employee' in user_roles (correct, drives login/redirect) but was
-- completely missing from access_role_assignments (the new access-control
-- system). With no row there, useModuleAccess treats them as not a
-- recognized staff member for ANY page, so every page check fails and the
-- app redirects in a loop to a "home" page it also can't access -- the
-- infinite loading spinner with no dashboard. Also profiles.role/user_type
-- were still 'user' instead of 'employee', out of sync same as other
-- accounts fixed today.

INSERT INTO access_role_assignments (user_id, role_key, assigned_by)
VALUES ('87c4ff72-d104-4f4c-b9af-c463e7e391b4', 'employee', '99f79b02-e597-4fcb-8556-874004dd9f5f')
ON CONFLICT (user_id) DO UPDATE SET role_key = EXCLUDED.role_key;

UPDATE profiles
SET role = 'employee', user_type = 'employee'
WHERE id = '87c4ff72-d104-4f4c-b9af-c463e7e391b4';
