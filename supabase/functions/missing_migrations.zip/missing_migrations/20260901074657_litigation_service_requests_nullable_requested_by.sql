-- Allow litigation_service_requests to be submitted on behalf of a
-- no-login (access-code) referring attorney via a service-role edge
-- function, the same way appointment_requests already works.
-- referring_attorney_id (FK to referring_attorneys) is always set and
-- is sufficient to attribute + notify + RLS-scope the request; requested_by
-- (FK to auth.users) is only meaningful for in-app authenticated submitters.
ALTER TABLE public.litigation_service_requests
  ALTER COLUMN requested_by DROP NOT NULL;

COMMENT ON COLUMN public.litigation_service_requests.requested_by IS
  'auth.users id of the submitter when made from the authenticated attorney/staff portal. NULL when submitted via a no-login access-code link (see referring_attorney_id + attorney_email/attorney_name for attribution in that case).';
