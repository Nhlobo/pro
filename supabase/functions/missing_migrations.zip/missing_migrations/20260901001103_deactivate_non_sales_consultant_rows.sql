
update sales_consultants sc
set is_active = false, updated_at = now()
from profiles p
where sc.user_id = p.id
  and p.role is distinct from 'sales_consultant';
