-- Verified before touching any of these:
--   1. Checked every RLS policy across ALL schemas (public + storage), filtered
--      to policies whose `roles` includes `public`/`anon` (the only ones an
--      anon connection would ever evaluate). Only 3 of the 41 candidates showed
--      up there: get_current_user_attorney_contact, get_current_user_portal_account_scope,
--      get_current_user_referring_attorney — those are NOT touched here.
--   2. For the rest, checked every actual call site in the frontend/edge
--      functions: every one is called from staff-authenticated hooks
--      (src/hooks/externalPortal/*, useHeatmapData, AddAttorneyDialog) or from
--      edge functions using the service-role client — never from anon context.
--   3. 8 of these are trigger functions (return type `trigger`), never meant
--      to be invoked directly by any client role.

-- Trigger-only functions: lock down for anon, authenticated, and PUBLIC.
REVOKE EXECUTE ON FUNCTION public.enqueue_sageone_invoice_on_appointment() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_case_messages_guard_external_update() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_report_delivery_billing() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_attorney_on_aod_document_ready() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_attorney_on_report_visible() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.protect_medical_expert_fee_columns() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.protect_sageone_field() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.sync_profile_last_login() FROM anon, authenticated, PUBLIC;

-- Standalone RPCs: revoke anon + PUBLIC, keep authenticated (staff/portal-admin
-- flows call these while logged in).
REVOKE EXECUTE ON FUNCTION public.assign_appointment_attorney_contact(uuid, uuid, text, text, text) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.can_access_payment_pop(text, uuid) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.claim_internal_invoice_delivery_batch(integer) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_attorney_contacts_by_usage(uuid) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_auto_expire_stale_accounts() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_log_audit(text, uuid, uuid, text, jsonb) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_medical_experts_by_usage() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_permanently_delete_account(uuid) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_referring_attorneys_by_usage() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_revoke_all_sessions(uuid, text) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_revoke_session(uuid, text) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_set_account_status(uuid, external_portal_account_status, text) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_unread_message_count() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_update_account_contact(uuid, uuid) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.external_portal_update_account_scope(uuid, external_portal_account_scope) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_current_user_external_portal_account_id() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_current_user_is_active() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_heatmap_demand_by_province() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_heatmap_experts_by_province() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_heatmap_province_stats() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.log_auth_event(uuid, text, text, text, text, text, text, jsonb) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.new_current_user_has_module(text) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.purge_expired_trusted_devices() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.reconcile_internal_invoices(boolean) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.record_auth_event(uuid, text, text, text, text, text, text, text, jsonb) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.search_pitchlog_firm_suggestions(text) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.send_appointment_reminders() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.send_missing_document_reminders() FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.snapshot_monthly_performance(date) FROM anon, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.user_can_view_case_document(text) FROM anon, PUBLIC;
