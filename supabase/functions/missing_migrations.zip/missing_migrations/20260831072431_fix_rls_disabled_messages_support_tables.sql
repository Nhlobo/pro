-- Same pattern as the previous fix: policies already exist and are well-scoped,
-- RLS enforcement was just switched off. Covers the 4 tables outside the
-- original 8 named areas (Messages/Support Hub) that the user asked to include.
ALTER TABLE public.external_portal_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.external_portal_case_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.internal_chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ticket_messages ENABLE ROW LEVEL SECURITY;
