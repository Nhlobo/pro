-- ===== expert_payments =====
ALTER POLICY "System admins full access to expert payments" ON public.expert_payments
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Users can create expert payments for their referring attorney" ON public.expert_payments
WITH CHECK (
  recorded_by = (select auth.uid()) AND (
    (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
    OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
        AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.referring_attorney_id = (select get_current_user_referring_attorney())))
    OR ((select get_current_user_attorney_contact()) IS NOT NULL
        AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.assigned_attorney_contact_id = (select get_current_user_attorney_contact())))
  )
);

ALTER POLICY "Admins and employees can view all expert payments" ON public.expert_payments
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.referring_attorney_id = (select get_current_user_referring_attorney()))
);

ALTER POLICY "Experts can view their own payments" ON public.expert_payments
USING (expert_id = (SELECT p.expert_id FROM profiles p WHERE p.id = (select auth.uid())));

ALTER POLICY "Finance and director can view all expert payments" ON public.expert_payments
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can view expert payments from their referring attorney" ON public.expert_payments
USING (
  ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
      AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.referring_attorney_id = (select get_current_user_referring_attorney())))
  OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope
      AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.referring_attorney_id = (select get_current_user_referring_attorney())))
  OR ((select get_current_user_attorney_contact()) IS NOT NULL
      AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.assigned_attorney_contact_id = (select get_current_user_attorney_contact())))
  OR ((select get_current_user_expert_id()) IS NOT NULL AND expert_id = (select get_current_user_expert_id()))
);

ALTER POLICY "Users can update expert payments from their referring attorney" ON public.expert_payments
USING (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
      AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.referring_attorney_id = (select get_current_user_referring_attorney())))
  OR ((select get_current_user_attorney_contact()) IS NOT NULL
      AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_payments.appointment_id AND a.assigned_attorney_contact_id = (select get_current_user_attorney_contact())))
);

-- ===== expert_reports =====
ALTER POLICY "Main admin full access to expert reports" ON public.expert_reports
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Users can delete expert reports from their referring attorney" ON public.expert_reports
USING (EXISTS (SELECT 1 FROM appointments WHERE appointments.id = expert_reports.appointment_id AND appointments.referring_attorney_id = (select get_current_user_referring_attorney())));

ALTER POLICY "Finance and director can create expert reports for payments" ON public.expert_reports
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can create expert reports for their referring attorney" ON public.expert_reports
WITH CHECK (EXISTS (SELECT 1 FROM appointments WHERE appointments.id = expert_reports.appointment_id AND appointments.referring_attorney_id = (select get_current_user_referring_attorney())));

ALTER POLICY "Admins and employees can view all expert reports" ON public.expert_reports
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
      AND EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_reports.appointment_id AND a.referring_attorney_id = (select get_current_user_referring_attorney())))
);

ALTER POLICY "Finance and director can view all expert reports" ON public.expert_reports
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can view expert reports from their referring attorney" ON public.expert_reports
USING (
  EXISTS (SELECT 1 FROM appointments a WHERE a.id = expert_reports.appointment_id AND a.deleted_at IS NULL AND (
    ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
        AND a.referring_attorney_id = (select get_current_user_referring_attorney()))
    OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope AND a.referring_attorney_id = (select get_current_user_referring_attorney()))
    OR ((select get_current_user_portal_account_scope()) = 'individual'::external_portal_account_scope AND a.assigned_attorney_contact_id IS NOT NULL AND a.assigned_attorney_contact_id = (select get_current_user_attorney_contact()))
  ))
  OR ((select get_current_user_expert_id()) IS NOT NULL AND expert_id = (select get_current_user_expert_id()))
);

ALTER POLICY "Experts can update their own expert reports" ON public.expert_reports
USING (expert_id IS NOT NULL AND expert_id = (select get_current_user_expert_id()))
WITH CHECK (expert_id IS NOT NULL AND expert_id = (select get_current_user_expert_id()));

ALTER POLICY "Finance and director can update expert reports for payments" ON public.expert_reports
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role))
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can update expert reports from their referring attorney" ON public.expert_reports
USING (EXISTS (SELECT 1 FROM appointments WHERE appointments.id = expert_reports.appointment_id AND appointments.referring_attorney_id = (select get_current_user_referring_attorney())))
WITH CHECK (EXISTS (SELECT 1 FROM appointments WHERE appointments.id = expert_reports.appointment_id AND appointments.referring_attorney_id = (select get_current_user_referring_attorney())));
