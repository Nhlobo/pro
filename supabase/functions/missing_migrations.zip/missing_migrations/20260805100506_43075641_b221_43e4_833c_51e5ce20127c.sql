
CREATE OR REPLACE FUNCTION public.get_heatmap_experts_by_province()
RETURNS TABLE(province text, expert_type text, matter_types text[], expert_count integer)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    public.normalize_province(e.province) AS province,
    coalesce(e.expert_type, 'Unknown') AS expert_type,
    e.matter_types::text[] AS matter_types,
    count(*)::int AS expert_count
  FROM public.medical_experts e
  WHERE e.status = 'active'
    AND coalesce(e.medico_legal_only, true) = true
  GROUP BY 1, 2, 3
$$;

CREATE OR REPLACE FUNCTION public.get_heatmap_demand_by_province()
RETURNS TABLE(province text, demand integer)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    public.normalize_province(e.province) AS province,
    count(*)::int AS demand
  FROM public.appointments a
  JOIN public.medical_experts e ON e.id = a.expert_id
  WHERE a.deleted_at IS NULL
    AND a.appointment_date >= (now() - interval '12 months')
  GROUP BY 1
$$;

GRANT EXECUTE ON FUNCTION public.get_heatmap_experts_by_province() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_heatmap_demand_by_province() TO authenticated, service_role;
