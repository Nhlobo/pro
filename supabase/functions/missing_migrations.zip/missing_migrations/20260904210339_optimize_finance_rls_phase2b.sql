-- ===== claimants =====
ALTER POLICY "Main admin full access to claimants" ON public.claimants
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Users can delete claimants based on role" ON public.claimants
USING (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR (referring_attorney_id = (select get_current_user_referring_attorney()) AND (select get_current_user_referring_attorney()) IS NOT NULL)
);

ALTER POLICY "Users can create claimants based on role" ON public.claimants
WITH CHECK (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR (referring_attorney_id = (select get_current_user_referring_attorney()) AND (select get_current_user_referring_attorney()) IS NOT NULL)
);

ALTER POLICY "Users can view claimants based on role" ON public.claimants
USING (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
      AND referring_attorney_id = (select get_current_user_referring_attorney()) AND (select get_current_user_referring_attorney()) IS NOT NULL)
  OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope
      AND referring_attorney_id = (select get_current_user_referring_attorney()) AND (select get_current_user_referring_attorney()) IS NOT NULL)
  OR ((select get_current_user_attorney_contact()) IS NOT NULL AND EXISTS (
      SELECT 1 FROM appointments a WHERE a.claimant_id = claimants.id AND a.assigned_attorney_contact_id = (select get_current_user_attorney_contact())))
  OR ((select get_current_user_expert_id()) IS NOT NULL AND EXISTS (
      SELECT 1 FROM appointments a WHERE a.claimant_id = claimants.id AND a.expert_id = (select get_current_user_expert_id())))
);

ALTER POLICY "Users can update claimants based on role" ON public.claimants
USING (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR (referring_attorney_id = (select get_current_user_referring_attorney()) AND (select get_current_user_referring_attorney()) IS NOT NULL)
)
WITH CHECK (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR (referring_attorney_id = (select get_current_user_referring_attorney()) AND (select get_current_user_referring_attorney()) IS NOT NULL)
);

-- ===== epp_invoices =====
ALTER POLICY "epp_invoices_delete" ON public.epp_invoices USING (epp_can_manage((select auth.uid())));
ALTER POLICY "epp_invoices_insert" ON public.epp_invoices WITH CHECK (epp_can_manage((select auth.uid())));
ALTER POLICY "epp_invoices_select" ON public.epp_invoices USING (epp_can_view((select auth.uid())));
ALTER POLICY "epp_invoices_update" ON public.epp_invoices USING (epp_can_manage((select auth.uid())));

-- ===== expert_payment_planner_snapshots =====
ALTER POLICY "Admins can delete planner snapshots" ON public.expert_payment_planner_snapshots
USING (has_role((select auth.uid()), 'admin'::app_role));

ALTER POLICY "Submitter can insert planner snapshots" ON public.expert_payment_planner_snapshots
WITH CHECK (submitted_by_id = (select auth.uid()) OR has_role((select auth.uid()), 'admin'::app_role));

ALTER POLICY "Finance staff can view planner snapshots" ON public.expert_payment_planner_snapshots
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role)
  OR submitted_by_id = (select auth.uid())
);

ALTER POLICY "Submitter or admin can update planner snapshots" ON public.expert_payment_planner_snapshots
USING (submitted_by_id = (select auth.uid()) OR has_role((select auth.uid()), 'admin'::app_role))
WITH CHECK (submitted_by_id = (select auth.uid()) OR has_role((select auth.uid()), 'admin'::app_role));
