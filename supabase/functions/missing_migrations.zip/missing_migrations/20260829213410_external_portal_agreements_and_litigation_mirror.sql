-- Mirror tables for the last three portal-facing internal tables:
-- aod_documents/aod_payments (AttorneyAgreements, AttorneyPayments)
-- and litigation_service_requests (LitigationTrialServices).
-- Only the columns those pages actually read are mirrored, not every
-- column (aod_documents has 60+ fields, many highly sensitive contract
-- terms never shown in the portal). RLS matches the existing policies
-- on the source tables exactly — same firm-scope-only visibility for
-- agreements (individual attorney-contacts see none, matching current
-- behavior), same requested_by-OR-firm visibility for litigation
-- requests. This does not change who can see what — only where the
-- portal reads it from. appointment_requests is intentionally not
-- mirrored: the portal only ever INSERTs into it (submitting new
-- requests), never reads it back, so there's nothing to isolate.

CREATE TABLE public.external_portal_agreements (
  id uuid PRIMARY KEY,
  referring_attorney_id uuid,
  file_name text,
  document_url text,
  total_contract_value numeric,
  deposit_amount numeric,
  total_reports_agreed integer,
  contract_start_date date,
  contract_end_date date,
  payment_status text,
  next_payment_date timestamptz,
  created_at timestamptz
);

ALTER TABLE public.external_portal_agreements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "External portal users view their own firm's agreements"
  ON public.external_portal_agreements FOR SELECT
  TO authenticated
  USING (
    is_system_admin()
    OR has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'employee'::app_role)
    OR (
      NOT COALESCE((SELECT p.is_external_portal_user FROM public.profiles p WHERE p.id = auth.uid()), false)
      AND referring_attorney_id = get_current_user_referring_attorney()
    )
    OR (
      get_current_user_portal_account_scope() = 'firm'::external_portal_account_scope
      AND referring_attorney_id = get_current_user_referring_attorney()
    )
  );

GRANT SELECT ON public.external_portal_agreements TO authenticated;

CREATE TABLE public.external_portal_agreement_payments (
  id uuid PRIMARY KEY,
  aod_document_id uuid,
  payment_amount numeric,
  payment_type text,
  payment_date date,
  payment_notes text
);

ALTER TABLE public.external_portal_agreement_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "External portal users view payments on their own agreements"
  ON public.external_portal_agreement_payments FOR SELECT
  TO authenticated
  USING (
    is_system_admin()
    OR has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'employee'::app_role)
    OR EXISTS (
      SELECT 1 FROM public.external_portal_agreements a WHERE a.id = external_portal_agreement_payments.aod_document_id
    )
  );

GRANT SELECT ON public.external_portal_agreement_payments TO authenticated;

CREATE TABLE public.external_portal_litigation_requests (
  id uuid PRIMARY KEY,
  service_type text,
  claimant_name text,
  case_reference text,
  urgency text,
  status text,
  description text,
  requested_by uuid,
  referring_attorney_id uuid,
  requested_at timestamptz,
  completed_at timestamptz
);

ALTER TABLE public.external_portal_litigation_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "External portal users view their own litigation requests"
  ON public.external_portal_litigation_requests FOR SELECT
  TO authenticated
  USING (
    is_system_admin()
    OR has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'employee'::app_role)
    OR requested_by = auth.uid()
    OR (
      NOT COALESCE((SELECT p.is_external_portal_user FROM public.profiles p WHERE p.id = auth.uid()), false)
      AND referring_attorney_id = get_current_user_referring_attorney()
    )
    OR (
      get_current_user_portal_account_scope() = 'firm'::external_portal_account_scope
      AND referring_attorney_id = get_current_user_referring_attorney()
    )
  );

GRANT SELECT ON public.external_portal_litigation_requests TO authenticated;

-- Sync triggers
CREATE OR REPLACE FUNCTION public.sync_external_portal_agreement()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.external_portal_agreements WHERE id = OLD.id;
    RETURN OLD;
  END IF;
  INSERT INTO public.external_portal_agreements (
    id, referring_attorney_id, file_name, document_url, total_contract_value,
    deposit_amount, total_reports_agreed, contract_start_date, contract_end_date,
    payment_status, next_payment_date, created_at
  ) VALUES (
    NEW.id, NEW.referring_attorney_id, NEW.file_name, NEW.document_url, NEW.total_contract_value,
    NEW.deposit_amount, NEW.total_reports_agreed, NEW.contract_start_date, NEW.contract_end_date,
    NEW.payment_status, NEW.next_payment_date, NEW.created_at
  )
  ON CONFLICT (id) DO UPDATE SET
    referring_attorney_id = EXCLUDED.referring_attorney_id, file_name = EXCLUDED.file_name,
    document_url = EXCLUDED.document_url, total_contract_value = EXCLUDED.total_contract_value,
    deposit_amount = EXCLUDED.deposit_amount, total_reports_agreed = EXCLUDED.total_reports_agreed,
    contract_start_date = EXCLUDED.contract_start_date, contract_end_date = EXCLUDED.contract_end_date,
    payment_status = EXCLUDED.payment_status, next_payment_date = EXCLUDED.next_payment_date;
  RETURN NEW;
END; $$;
REVOKE ALL ON FUNCTION public.sync_external_portal_agreement() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER trg_sync_external_portal_agreement
AFTER INSERT OR UPDATE OF referring_attorney_id, file_name, document_url, total_contract_value,
  deposit_amount, total_reports_agreed, contract_start_date, contract_end_date, payment_status, next_payment_date
OR DELETE ON public.aod_documents
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_agreement();

CREATE OR REPLACE FUNCTION public.sync_external_portal_agreement_payment()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.external_portal_agreement_payments WHERE id = OLD.id;
    RETURN OLD;
  END IF;
  INSERT INTO public.external_portal_agreement_payments (id, aod_document_id, payment_amount, payment_type, payment_date, payment_notes)
  VALUES (NEW.id, NEW.aod_document_id, NEW.payment_amount, NEW.payment_type, NEW.payment_date, NEW.payment_notes)
  ON CONFLICT (id) DO UPDATE SET
    aod_document_id = EXCLUDED.aod_document_id, payment_amount = EXCLUDED.payment_amount,
    payment_type = EXCLUDED.payment_type, payment_date = EXCLUDED.payment_date, payment_notes = EXCLUDED.payment_notes;
  RETURN NEW;
END; $$;
REVOKE ALL ON FUNCTION public.sync_external_portal_agreement_payment() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER trg_sync_external_portal_agreement_payment
AFTER INSERT OR UPDATE OF aod_document_id, payment_amount, payment_type, payment_date, payment_notes
OR DELETE ON public.aod_payments
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_agreement_payment();

CREATE OR REPLACE FUNCTION public.sync_external_portal_litigation_request()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.external_portal_litigation_requests WHERE id = OLD.id;
    RETURN OLD;
  END IF;
  INSERT INTO public.external_portal_litigation_requests (
    id, service_type, claimant_name, case_reference, urgency, status, description,
    requested_by, referring_attorney_id, requested_at, completed_at
  ) VALUES (
    NEW.id, NEW.service_type, NEW.claimant_name, NEW.case_reference, NEW.urgency, NEW.status, NEW.description,
    NEW.requested_by, NEW.referring_attorney_id, NEW.requested_at, NEW.completed_at
  )
  ON CONFLICT (id) DO UPDATE SET
    service_type = EXCLUDED.service_type, claimant_name = EXCLUDED.claimant_name,
    case_reference = EXCLUDED.case_reference, urgency = EXCLUDED.urgency, status = EXCLUDED.status,
    description = EXCLUDED.description, requested_by = EXCLUDED.requested_by,
    referring_attorney_id = EXCLUDED.referring_attorney_id, requested_at = EXCLUDED.requested_at,
    completed_at = EXCLUDED.completed_at;
  RETURN NEW;
END; $$;
REVOKE ALL ON FUNCTION public.sync_external_portal_litigation_request() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER trg_sync_external_portal_litigation_request
AFTER INSERT OR UPDATE OF service_type, claimant_name, case_reference, urgency, status, description,
  requested_by, referring_attorney_id, completed_at
OR DELETE ON public.litigation_service_requests
FOR EACH ROW EXECUTE FUNCTION public.sync_external_portal_litigation_request();

-- Backfill
INSERT INTO public.external_portal_agreements
  SELECT id, referring_attorney_id, file_name, document_url, total_contract_value, deposit_amount,
    total_reports_agreed, contract_start_date, contract_end_date, payment_status, next_payment_date, created_at
  FROM public.aod_documents ON CONFLICT (id) DO NOTHING;

INSERT INTO public.external_portal_agreement_payments
  SELECT id, aod_document_id, payment_amount, payment_type, payment_date, payment_notes
  FROM public.aod_payments ON CONFLICT (id) DO NOTHING;

INSERT INTO public.external_portal_litigation_requests
  SELECT id, service_type, claimant_name, case_reference, urgency, status, description,
    requested_by, referring_attorney_id, requested_at, completed_at
  FROM public.litigation_service_requests ON CONFLICT (id) DO NOTHING;
