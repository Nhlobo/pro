-- SECURITY FIX: profiles_external_portal_not_staff_chk (Phase 7) only
-- blocked is_external_portal_user = true together with role/user_type
-- 'admin' or 'employee'. It never accounted for the other internal
-- staff roles this schema actually allows -- sales_consultant, finance,
-- director (see profiles_role_check) -- so a finance/sales/director
-- account could be flagged is_external_portal_user = true without ever
-- violating this constraint. Widen it to cover every internal staff role.
ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_external_portal_not_staff_chk;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_external_portal_not_staff_chk
  CHECK (
    NOT (
      is_external_portal_user
      AND (
        role IN ('admin', 'employee', 'sales_consultant', 'finance', 'director')
        OR user_type IN ('admin', 'employee', 'staff', 'super_user', 'sales_consultant', 'finance', 'director')
      )
    )
  );
