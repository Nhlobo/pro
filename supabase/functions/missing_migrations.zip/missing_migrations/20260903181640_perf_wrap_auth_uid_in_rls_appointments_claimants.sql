-- Wrap bare auth.uid() calls in (select auth.uid()) so Postgres evaluates
-- them once per query instead of once per row. Predicates are logically
-- identical; this only changes performance, not access.

-- appointments
ALTER POLICY "Admins and employees can view all appointments for debt managem" ON public.appointments
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role) OR
  ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false))
   AND (referring_attorney_id = get_current_user_referring_attorney()))
);

ALTER POLICY "Employees can update appointments" ON public.appointments
USING (has_role((select auth.uid()), 'employee'::app_role))
WITH CHECK (has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Finance and director can view all appointments for debt managem" ON public.appointments
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can update appointments from their referring attorney" ON public.appointments
USING (
  (((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false))
    AND (referring_attorney_id = get_current_user_referring_attorney()))
   OR ((assigned_attorney_contact_id IS NOT NULL) AND (assigned_attorney_contact_id = get_current_user_attorney_contact()))
   OR ((expert_id IS NOT NULL) AND (expert_id = get_current_user_expert_id())))
)
WITH CHECK (
  (((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false))
    AND (referring_attorney_id = get_current_user_referring_attorney()))
   OR ((assigned_attorney_contact_id IS NOT NULL) AND (assigned_attorney_contact_id = get_current_user_attorney_contact()))
   OR ((expert_id IS NOT NULL) AND (expert_id = get_current_user_expert_id())))
);

ALTER POLICY "Users can view appointments from their referring attorney" ON public.appointments
USING (
  (deleted_at IS NULL) AND (
    ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false))
      AND (referring_attorney_id = get_current_user_referring_attorney()))
    OR ((get_current_user_portal_account_scope() = 'firm'::external_portal_account_scope) AND (referring_attorney_id = get_current_user_referring_attorney()))
    OR ((get_current_user_portal_account_scope() = 'individual'::external_portal_account_scope) AND (assigned_attorney_contact_id IS NOT NULL) AND (assigned_attorney_contact_id = get_current_user_attorney_contact()))
    OR ((get_current_user_expert_id() IS NOT NULL) AND (expert_id = get_current_user_expert_id()))
  )
);

-- claimants
ALTER POLICY "Finance and director can view all claimants" ON public.claimants
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can create claimants based on role" ON public.claimants
WITH CHECK (
  is_system_admin() OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((referring_attorney_id = get_current_user_referring_attorney()) AND (get_current_user_referring_attorney() IS NOT NULL))
);

ALTER POLICY "Users can delete claimants based on role" ON public.claimants
USING (
  is_system_admin() OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((referring_attorney_id = get_current_user_referring_attorney()) AND (get_current_user_referring_attorney() IS NOT NULL))
);

ALTER POLICY "Users can update claimants based on role" ON public.claimants
USING (
  is_system_admin() OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((referring_attorney_id = get_current_user_referring_attorney()) AND (get_current_user_referring_attorney() IS NOT NULL))
)
WITH CHECK (
  is_system_admin() OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((referring_attorney_id = get_current_user_referring_attorney()) AND (get_current_user_referring_attorney() IS NOT NULL))
);

ALTER POLICY "Users can view claimants based on role" ON public.claimants
USING (
  is_system_admin() OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false))
      AND (referring_attorney_id = get_current_user_referring_attorney()) AND (get_current_user_referring_attorney() IS NOT NULL))
  OR ((get_current_user_portal_account_scope() = 'firm'::external_portal_account_scope) AND (referring_attorney_id = get_current_user_referring_attorney()) AND (get_current_user_referring_attorney() IS NOT NULL))
  OR ((get_current_user_attorney_contact() IS NOT NULL) AND (EXISTS (SELECT 1 FROM appointments a WHERE ((a.claimant_id = claimants.id) AND (a.assigned_attorney_contact_id = get_current_user_attorney_contact())))))
  OR ((get_current_user_expert_id() IS NOT NULL) AND (EXISTS (SELECT 1 FROM appointments a WHERE ((a.claimant_id = claimants.id) AND (a.expert_id = get_current_user_expert_id())))))
);
