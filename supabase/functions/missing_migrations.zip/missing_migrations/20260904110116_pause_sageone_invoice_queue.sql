-- Explicit, DB-level pause for the legacy SageOne invoice integration.
-- Independent of whether SAGEONE_API_URL/SAGEONE_API_KEY env vars are
-- ever set on the sageone-processor function — this flag has to be
-- flipped to false separately before it will send anything live.
insert into public.system_settings (setting_key, setting_value, updated_at)
values ('sageone_invoice_sending_paused', 'true'::jsonb, now())
on conflict (setting_key) do update set setting_value = 'true'::jsonb, updated_at = now();

-- Same "finance/director can toggle this one setting" shape already used
-- for internal_invoice_sending_paused, so re-enabling it later (once the
-- API key is in place) doesn't need another migration.
create policy "Finance and director can toggle sageone invoice pause"
  on public.system_settings
  for update
  to authenticated
  using (setting_key = 'sageone_invoice_sending_paused' and (has_role(auth.uid(), 'finance'::app_role) or has_role(auth.uid(), 'director'::app_role)))
  with check (setting_key = 'sageone_invoice_sending_paused' and (has_role(auth.uid(), 'finance'::app_role) or has_role(auth.uid(), 'director'::app_role)));

-- sageone_invoice_queue had RLS enabled with zero policies (flagged by
-- the Supabase security advisor) — nobody but the service role could
-- read it, including admin/employee/finance/director in the app. Adding
-- read access only (writes stay service-role-only via the edge
-- function), matching the pattern already used for
-- internal_invoice_delivery_queue.
create policy "Admin and employees can view sageone_invoice_queue"
  on public.sageone_invoice_queue
  for select
  to authenticated
  using (has_role(auth.uid(), 'admin'::app_role) or has_role(auth.uid(), 'employee'::app_role));

create policy "Finance and director can view sageone_invoice_queue"
  on public.sageone_invoice_queue
  for select
  to authenticated
  using (has_role(auth.uid(), 'finance'::app_role) or has_role(auth.uid(), 'director'::app_role));
