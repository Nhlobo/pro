-- ===== notifications =====
ALTER POLICY "System admins full access to notifications" ON public.notifications
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

-- NOTE: "Finance and director can notify admins of approval requests" left untouched:
-- its has_role(user_id, 'admin') call uses the row's own user_id column, not auth.uid(),
-- so it's inherently row-dependent and can't be cached with (select ...).

ALTER POLICY "Users can create their own notifications, staff can create any" ON public.notifications
WITH CHECK ((select auth.uid()) = user_id OR (select is_admin_or_employee()));

-- ===== payment_pop_attachments =====
ALTER POLICY "Admins manage all POPs" ON public.payment_pop_attachments
USING (has_role((select auth.uid()), 'admin'::app_role)) WITH CHECK (has_role((select auth.uid()), 'admin'::app_role));

ALTER POLICY "Staff can delete payment POPs" ON public.payment_pop_attachments
USING ((select is_admin_or_employee()));

ALTER POLICY "Staff can upload payment POPs" ON public.payment_pop_attachments
WITH CHECK ((select is_admin_or_employee()) AND uploaded_by = (select auth.uid()));

ALTER POLICY "Users insert own POPs" ON public.payment_pop_attachments
WITH CHECK (uploaded_by = (select auth.uid()));

ALTER POLICY "Finance and director can view all payment POPs" ON public.payment_pop_attachments
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

-- NOTE: "Staff and owning attorney can view payment POPs" left untouched:
-- can_access_payment_pop(record_type, record_id) takes this row's own columns as
-- arguments, so it's inherently row-dependent and can't be cached with (select ...).

ALTER POLICY "Users read own POPs" ON public.payment_pop_attachments
USING (uploaded_by = (select auth.uid()));

ALTER POLICY "Staff can update payment POPs" ON public.payment_pop_attachments
USING ((select is_admin_or_employee())) WITH CHECK ((select is_admin_or_employee()));

ALTER POLICY "Users update own POPs" ON public.payment_pop_attachments
USING (uploaded_by = (select auth.uid())) WITH CHECK (uploaded_by = (select auth.uid()));

-- ===== payment_report_allocations =====
ALTER POLICY "Staff can delete payment allocations" ON public.payment_report_allocations
USING ((select is_admin_or_employee()));

ALTER POLICY "Finance and director can create payment allocations" ON public.payment_report_allocations
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Staff can insert payment allocations" ON public.payment_report_allocations
WITH CHECK ((select is_admin_or_employee()));

ALTER POLICY "Finance and director can view payment allocations" ON public.payment_report_allocations
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Staff can view payment allocations" ON public.payment_report_allocations
USING ((select is_admin_or_employee()) OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.referring_attorney_id IS NOT NULL AND p.referring_attorney_id = payment_report_allocations.referring_attorney_id
));

-- ===== sageone_invoice_queue =====
ALTER POLICY "Admin and employees can view sageone_invoice_queue" ON public.sageone_invoice_queue
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Finance and director can view sageone_invoice_queue" ON public.sageone_invoice_queue
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

-- ===== system_settings =====
ALTER POLICY "Admins can manage system settings" ON public.system_settings
USING (has_role((select auth.uid()), 'admin'::app_role)) WITH CHECK (has_role((select auth.uid()), 'admin'::app_role));

ALTER POLICY "Employees can read system settings" ON public.system_settings
USING (has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Finance and director can toggle internal invoice pause" ON public.system_settings
USING (setting_key = 'internal_invoice_sending_paused'::text AND (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role)))
WITH CHECK (setting_key = 'internal_invoice_sending_paused'::text AND (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role)));

ALTER POLICY "Finance and director can toggle sageone invoice pause" ON public.system_settings
USING (setting_key = 'sageone_invoice_sending_paused'::text AND (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role)))
WITH CHECK (setting_key = 'sageone_invoice_sending_paused'::text AND (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role)));

-- ===== weekly_operations_reports =====
ALTER POLICY "Admins manage operations reports" ON public.weekly_operations_reports
USING (has_role((select auth.uid()), 'admin'::app_role)) WITH CHECK (has_role((select auth.uid()), 'admin'::app_role));

ALTER POLICY "Admins manage weekly operations reports" ON public.weekly_operations_reports
USING (has_role((select auth.uid()), 'admin'::app_role)) WITH CHECK (has_role((select auth.uid()), 'admin'::app_role));

ALTER POLICY "Finance and directors view weekly operations reports" ON public.weekly_operations_reports
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users view their own operations reports" ON public.weekly_operations_reports
USING (generated_for_user_id = (select auth.uid()) AND is_combined = false);

-- ===== referring_attorneys: the two remaining unwrapped calls =====
ALTER POLICY "Main admin full access to law firms" ON public.referring_attorneys
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Admins and employees can delete referring attorneys" ON public.referring_attorneys
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role) OR (select is_system_admin()));

ALTER POLICY "Medical experts can view referring attorneys on their own cases" ON public.referring_attorneys
USING ((select get_current_user_expert_id()) IS NOT NULL AND EXISTS (
  SELECT 1 FROM appointments a WHERE a.referring_attorney_id = referring_attorneys.id AND a.expert_id = (select get_current_user_expert_id()) AND a.deleted_at IS NULL
));

ALTER POLICY "Users can view own referring attorney only" ON public.referring_attorneys
USING (
  (select auth.uid()) IS NOT NULL AND id IS NOT NULL AND (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.referring_attorney_id = referring_attorneys.id AND p.referring_attorney_id IS NOT NULL AND p.created_at IS NOT NULL AND p.created_at <= now())
    OR ((select get_current_user_expert_id()) IS NOT NULL AND EXISTS (SELECT 1 FROM appointments a WHERE a.referring_attorney_id = referring_attorneys.id AND a.expert_id = (select get_current_user_expert_id())))
  )
);
