-- The Finance & Payments page's "Internal Invoices" tab joins
-- internal_invoices with internal_invoice_delivery_queue and
-- internal_invoice_email_log. Employees already had SELECT on the queue
-- and email-log tables (see "Admin and employees can view
-- internal_invoice_delivery_queue" / "..._email_log"), but there was no
-- policy granting them SELECT on internal_invoices itself — only
-- 'finance'/'director' (via has_role) and a separate legacy check tied to
-- profiles.role = 'admin'. Net effect: an employee opening this tab saw
-- delivery/email rows with no invoice they were allowed to read attached
-- to them, i.e. the tab looked broken/empty depending on who was logged
-- in even though the same underlying data existed for everyone.
--
-- This adds the same "admin or employee" SELECT policy already used
-- consistently on the two related tables, so all four roles named for
-- this page (admin, employee, finance, director) can read invoices.
create policy "Admin and employees can view internal_invoices"
  on public.internal_invoices
  for select
  to authenticated
  using (has_role(auth.uid(), 'admin'::app_role) or has_role(auth.uid(), 'employee'::app_role));
