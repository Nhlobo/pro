REVOKE ALL ON public.external_portal_agreements FROM anon;
REVOKE ALL ON public.external_portal_agreement_payments FROM anon;
REVOKE ALL ON public.external_portal_litigation_requests FROM anon;

REVOKE INSERT, UPDATE, DELETE, TRUNCATE, TRIGGER, REFERENCES ON public.external_portal_agreements FROM authenticated;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, TRIGGER, REFERENCES ON public.external_portal_agreement_payments FROM authenticated;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, TRIGGER, REFERENCES ON public.external_portal_litigation_requests FROM authenticated;
