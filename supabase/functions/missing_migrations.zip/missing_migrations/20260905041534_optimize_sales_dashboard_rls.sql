-- Same mechanical fix as Finance & Payments: wrap auth.uid()/helper-function
-- calls in RLS quals with (select ...) so Postgres evaluates them once per
-- query instead of once per row. Applied to the Sales Dashboard's tables
-- and the notification tables it/other dashboards touch.

-- ===== attorney_pitchlog =====
ALTER POLICY "Admin and employees can manage pitchlog" ON public.attorney_pitchlog
USING (
  EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = (select auth.uid()) AND ur.role = ANY (ARRAY['admin'::app_role, 'employee'::app_role]))
  OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.role = ANY (ARRAY['admin'::text, 'employee'::text]))
);

ALTER POLICY "Sales consultants can delete own pitchlog" ON public.attorney_pitchlog
USING (has_role((select auth.uid()), 'sales_consultant'::app_role) AND consultant_id IN (SELECT sales_consultants.id FROM sales_consultants WHERE sales_consultants.user_id = (select auth.uid())));

ALTER POLICY "Sales consultants can insert own pitchlog" ON public.attorney_pitchlog
WITH CHECK (has_role((select auth.uid()), 'sales_consultant'::app_role) AND (consultant_id IN (SELECT sales_consultants.id FROM sales_consultants WHERE sales_consultants.user_id = (select auth.uid())) OR consultant_id IS NULL));

ALTER POLICY "Sales consultants can view own pitchlog" ON public.attorney_pitchlog
USING (has_role((select auth.uid()), 'sales_consultant'::app_role) AND consultant_id IN (SELECT sales_consultants.id FROM sales_consultants WHERE sales_consultants.user_id = (select auth.uid())));

ALTER POLICY "Sales consultants can update own pitchlog" ON public.attorney_pitchlog
USING (has_role((select auth.uid()), 'sales_consultant'::app_role) AND consultant_id IN (SELECT sales_consultants.id FROM sales_consultants WHERE sales_consultants.user_id = (select auth.uid())))
WITH CHECK (has_role((select auth.uid()), 'sales_consultant'::app_role) AND consultant_id IN (SELECT sales_consultants.id FROM sales_consultants WHERE sales_consultants.user_id = (select auth.uid())));

-- ===== sales_consultants =====
ALTER POLICY "Admins can manage consultants" ON public.sales_consultants
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Staff or self can view consultants" ON public.sales_consultants
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR has_role((select auth.uid()), 'director'::app_role) OR user_id = (select auth.uid())
);

-- ===== sales_team_targets =====
ALTER POLICY "Admins can delete targets" ON public.sales_team_targets USING ((select is_admin_or_employee()));
ALTER POLICY "Admins can insert targets" ON public.sales_team_targets WITH CHECK ((select is_admin_or_employee()));
ALTER POLICY "Authenticated can view targets" ON public.sales_team_targets USING ((select auth.uid()) IS NOT NULL);
ALTER POLICY "Admins can update targets" ON public.sales_team_targets
USING ((select is_admin_or_employee())) WITH CHECK ((select is_admin_or_employee()));

-- ===== monthly_performance =====
ALTER POLICY "Admins can manage performance" ON public.monthly_performance
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Users can view own performance" ON public.monthly_performance
USING (
  consultant_id IN (SELECT sales_consultants.id FROM sales_consultants WHERE sales_consultants.user_id = (select auth.uid()))
  OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
);

-- ===== pitchlog_weekly_summaries =====
ALTER POLICY "Admin and employees can manage weekly summaries" ON public.pitchlog_weekly_summaries
USING (
  EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = (select auth.uid()) AND ur.role = ANY (ARRAY['admin'::app_role, 'employee'::app_role]))
  OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = (select auth.uid()) AND p.role = ANY (ARRAY['admin'::text, 'employee'::text]))
);

ALTER POLICY "Sales consultants can manage weekly summaries" ON public.pitchlog_weekly_summaries
USING (has_role((select auth.uid()), 'sales_consultant'::app_role)) WITH CHECK (has_role((select auth.uid()), 'sales_consultant'::app_role));

-- ===== employee_notifications =====
ALTER POLICY "Main admin full access to employee notifications" ON public.employee_notifications
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "System admins full access to employee notifications" ON public.employee_notifications
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Only admins can manage employee notifications" ON public.employee_notifications
USING (EXISTS (SELECT 1 FROM profiles WHERE profiles.id = (select auth.uid()) AND profiles.role = 'admin'::text));

ALTER POLICY "Users can view their own notification settings" ON public.employee_notifications
USING (user_id = (select auth.uid()));

ALTER POLICY "Users can update their own notification settings" ON public.employee_notifications
USING (user_id = (select auth.uid()));

-- ===== external_portal_notifications =====
ALTER POLICY "Admins manage external portal notifications" ON public.external_portal_notifications
USING (has_role((select auth.uid()), 'admin'::app_role)) WITH CHECK (has_role((select auth.uid()), 'admin'::app_role));
