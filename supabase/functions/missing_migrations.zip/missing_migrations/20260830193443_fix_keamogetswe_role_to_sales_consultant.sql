-- Keamogetswe (460cc46d-d060-45dd-afb5-d460d0db8089) was tagged role
-- 'employee' but position 'sales_consultant' -- confirmed by the business
-- owner she IS a Sales Consultant. Aligning role across all three sources
-- of truth (user_roles, access_role_assignments, profiles) so she now
-- correctly lands on /admin/sales-dashboard with the Sales Consultant
-- module set, same as the other sales consultants, instead of the broader
-- Employee access she had by mistake.

UPDATE user_roles
SET role = 'sales_consultant'
WHERE user_id = '460cc46d-d060-45dd-afb5-d460d0db8089' AND role = 'employee';

UPDATE access_role_assignments
SET role_key = 'sales_consultant'
WHERE user_id = '460cc46d-d060-45dd-afb5-d460d0db8089' AND role_key = 'employee';

UPDATE profiles
SET role = 'sales_consultant', user_type = 'user'
WHERE id = '460cc46d-d060-45dd-afb5-d460d0db8089';
