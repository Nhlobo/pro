-- src/config/adminModules.ts explicitly grants the "Assessment Reports &
-- Statistics" module to roles: ['admin', 'employee', 'director'] — but
-- assessment_report_archives had no RLS policy at all for 'director'
-- (only is_system_admin(), i.e. admin/employee, and the external
-- referring-attorney-scoped policy). Not currently hit in practice
-- because the one place this table is read (the archive-assessment-data
-- edge function) uses the service-role key, which bypasses RLS — but
-- that's a fragile reason for it to work, and it would break the moment
-- anything reads this table directly from the browser with the user's
-- own session. Bringing the policy in line with the declared access list.
create policy "Director can view assessment archives"
  on public.assessment_report_archives
  for select
  to authenticated
  using (has_role(auth.uid(), 'director'::app_role));
