DROP POLICY IF EXISTS "Sales consultants can manage pitchlog" ON public.attorney_pitchlog;

CREATE POLICY "Sales consultants can view own pitchlog"
ON public.attorney_pitchlog FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'sales_consultant'::app_role)
  AND consultant_id IN (SELECT id FROM public.sales_consultants WHERE user_id = auth.uid())
);

CREATE POLICY "Sales consultants can insert own pitchlog"
ON public.attorney_pitchlog FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'sales_consultant'::app_role)
  AND (
    consultant_id IN (SELECT id FROM public.sales_consultants WHERE user_id = auth.uid())
    OR consultant_id IS NULL
  )
);

CREATE POLICY "Sales consultants can update own pitchlog"
ON public.attorney_pitchlog FOR UPDATE
TO authenticated
USING (
  has_role(auth.uid(), 'sales_consultant'::app_role)
  AND consultant_id IN (SELECT id FROM public.sales_consultants WHERE user_id = auth.uid())
)
WITH CHECK (
  has_role(auth.uid(), 'sales_consultant'::app_role)
  AND consultant_id IN (SELECT id FROM public.sales_consultants WHERE user_id = auth.uid())
);

CREATE POLICY "Sales consultants can delete own pitchlog"
ON public.attorney_pitchlog FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'sales_consultant'::app_role)
  AND consultant_id IN (SELECT id FROM public.sales_consultants WHERE user_id = auth.uid())
);
