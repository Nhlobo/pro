-- Sales Consultant should only ever see: Attorney CRM, Availability
-- Heatmap, and My Profile. Find Experts and Attorney & Expert Portal
-- Access were previously eligible for this role in role_module_defaults
-- (the live source of truth read by useModuleAccess/newAccessControlQuery
-- since NEW_ACCESS_CONTROL_ENABLED = true) — tighten to match.
--
-- No position_module_overrides or user_module_overrides exist for this
-- role/module combination (checked before writing this migration), and
-- is_eligible = false forces a deny regardless of any override added
-- later (see fetchNewSystemAccess), so this is a complete lock-down.
update role_module_defaults
set is_eligible = false, is_default_on = false
where role_key = 'sales_consultant'
  and module_key in ('find-experts', 'external-portal-access');

-- Stale row left over from the removal of the standalone 'sales-dashboard'
-- module/route (that page was a duplicate of the Sales Dashboard tab
-- already inside Attorney CRM). The module_key no longer exists in
-- ADMIN_MODULES, so this row is now dead data — remove it rather than
-- leaving an orphaned reference sitting in the defaults table.
delete from role_module_defaults
where role_key = 'sales_consultant'
  and module_key = 'sales-dashboard';
