-- Finance and Director both have the "Expert Payment Planner" module
-- granted (role_module_defaults), which reads expert_payments and
-- expert_reports alongside appointments/claimants/medical_experts --
-- all of which already carry a "Finance and director can view all X"
-- policy. expert_payments and expert_reports were missing the same
-- policy, so those two roles could open the page but never see any
-- payment or report rows under RLS. Adding the same pattern used
-- everywhere else for these roles.

CREATE POLICY "Finance and director can view all expert payments"
ON public.expert_payments
FOR SELECT
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);

CREATE POLICY "Finance and director can view all expert reports"
ON public.expert_reports
FOR SELECT
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);
