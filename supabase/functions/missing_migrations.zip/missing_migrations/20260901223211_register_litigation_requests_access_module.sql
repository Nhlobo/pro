-- Register the litigation-requests module itself before granting roles
-- access to it (role_module_defaults.module_key is FK'd to this table).
insert into access_modules (module_key, title, description, group_name, route_path, is_active)
values (
  'litigation-requests',
  'Litigation Service Requests',
  'Addendum, Affidavit, Joint Minute and related litigation service requests from referring attorneys',
  'Workflow',
  '/admin/litigation-requests',
  true
)
on conflict (module_key) do nothing;

insert into role_module_defaults (role_key, module_key, is_eligible, is_default_on)
values
  ('admin', 'litigation-requests', true, true),
  ('employee', 'litigation-requests', true, true),
  ('finance', 'litigation-requests', false, false),
  ('director', 'litigation-requests', false, false),
  ('sales_consultant', 'litigation-requests', false, false)
on conflict (role_key, module_key) do nothing;
