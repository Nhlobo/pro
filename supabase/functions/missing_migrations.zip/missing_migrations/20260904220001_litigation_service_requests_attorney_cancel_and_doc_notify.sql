-- 1) Track whether a cancellation was made by the requesting attorney
--    (self-service, portal) vs by staff (AdminLitigationRequests.tsx).
--    Both write the same cancellation_reason column; this just flags
--    who did it so the UI can label it correctly on either side.
ALTER TABLE public.litigation_service_requests
  ADD COLUMN IF NOT EXISTS cancelled_by_requester boolean NOT NULL DEFAULT false;

-- 2) The external portal mirror never got cancellation_reason (it was
--    staff-only info when only staff could cancel). Now that attorneys
--    can cancel their own requests and need to see why/who, both
--    columns need to be visible on their side too.
ALTER TABLE public.external_portal_litigation_requests
  ADD COLUMN IF NOT EXISTS cancellation_reason text,
  ADD COLUMN IF NOT EXISTS cancelled_by_requester boolean NOT NULL DEFAULT false;

-- 3) Sync function: add the two columns above to what gets mirrored.
CREATE OR REPLACE FUNCTION public.sync_external_portal_litigation_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.external_portal_litigation_requests WHERE id = OLD.id;
    RETURN OLD;
  END IF;
  INSERT INTO public.external_portal_litigation_requests (
    id, service_type, claimant_name, case_reference, urgency, status, description,
    requested_by, referring_attorney_id, requested_at, completed_at,
    response_document_path, response_document_name, response_document_uploaded_at,
    cancellation_reason, cancelled_by_requester
  ) VALUES (
    NEW.id, NEW.service_type, NEW.claimant_name, NEW.case_reference, NEW.urgency, NEW.status, NEW.description,
    NEW.requested_by, NEW.referring_attorney_id, NEW.requested_at, NEW.completed_at,
    NEW.response_document_path, NEW.response_document_name, NEW.response_document_uploaded_at,
    NEW.cancellation_reason, NEW.cancelled_by_requester
  )
  ON CONFLICT (id) DO UPDATE SET
    service_type = EXCLUDED.service_type, claimant_name = EXCLUDED.claimant_name,
    case_reference = EXCLUDED.case_reference, urgency = EXCLUDED.urgency, status = EXCLUDED.status,
    description = EXCLUDED.description, requested_by = EXCLUDED.requested_by,
    referring_attorney_id = EXCLUDED.referring_attorney_id, requested_at = EXCLUDED.requested_at,
    completed_at = EXCLUDED.completed_at,
    response_document_path = EXCLUDED.response_document_path,
    response_document_name = EXCLUDED.response_document_name,
    response_document_uploaded_at = EXCLUDED.response_document_uploaded_at,
    cancellation_reason = EXCLUDED.cancellation_reason,
    cancelled_by_requester = EXCLUDED.cancelled_by_requester;
  RETURN NEW;
END; $function$;

-- 4) Backfill the mirror table for existing rows so history isn't lost
--    (the trigger only fires on future writes).
UPDATE public.external_portal_litigation_requests epr
SET cancellation_reason = lsr.cancellation_reason,
    cancelled_by_requester = lsr.cancelled_by_requester
FROM public.litigation_service_requests lsr
WHERE epr.id = lsr.id
  AND (epr.cancellation_reason IS DISTINCT FROM lsr.cancellation_reason
       OR epr.cancelled_by_requester IS DISTINCT FROM lsr.cancelled_by_requester);

-- 5) Safe, narrow self-service cancel for attorneys. Not exposed via a
--    broad RLS UPDATE policy (that would let a portal user edit any
--    column, including forging status='completed') — a SECURITY
--    DEFINER RPC that only ever sets status/cancellation_reason/
--    cancelled_by_requester, only on the caller's own pending request.
CREATE OR REPLACE FUNCTION public.attorney_cancel_litigation_service_request(p_id uuid, p_reason text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_row public.litigation_service_requests%ROWTYPE;
BEGIN
  IF p_reason IS NULL OR length(trim(p_reason)) = 0 THEN
    RAISE EXCEPTION 'A cancellation reason is required.';
  END IF;

  SELECT * INTO v_row FROM public.litigation_service_requests WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Request not found.';
  END IF;

  IF v_row.requested_by IS DISTINCT FROM auth.uid() THEN
    RAISE EXCEPTION 'You can only cancel your own requests.';
  END IF;

  IF v_row.status <> 'pending' THEN
    RAISE EXCEPTION 'Only a request that is still Pending can be cancelled from the portal. Contact us to cancel a request already in progress.';
  END IF;

  UPDATE public.litigation_service_requests
  SET status = 'cancelled',
      cancellation_reason = trim(p_reason),
      cancelled_by_requester = true,
      updated_at = now()
  WHERE id = p_id;
END;
$function$;

GRANT EXECUTE ON FUNCTION public.attorney_cancel_litigation_service_request(uuid, text) TO authenticated;
