-- `aod_documents` and `short_term_agreements` are already subscribed to in the
-- frontend's global sync channel (AppointmentSyncContext.tsx) but were never
-- added to the supabase_realtime publication, so those subscriptions have
-- been silently firing zero events since day one.
-- medical_experts and referring_attorneys are being newly wired into the
-- global sync channel in this same pass.
-- (Note: "scheduled_assessments" is not a real table — get_scheduled_assessments_secure
-- is built from appointments+claimants+medical_experts+expert_reports, all of
-- which are already, or about to be, in this publication.)

ALTER PUBLICATION supabase_realtime ADD TABLE public.aod_documents;
ALTER PUBLICATION supabase_realtime ADD TABLE public.short_term_agreements;
ALTER PUBLICATION supabase_realtime ADD TABLE public.medical_experts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.referring_attorneys;
