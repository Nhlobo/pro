-- =====================================================================
-- Litigation Service Requests — parity fixes (1 of 3)
--
-- 1. Audit trail: litigation_service_requests had no audit trigger at
--    all, unlike appointment_requests (audit_writes_appointment_requests).
--    Reuses the existing generic audit_write_event() function.
--
-- 2. Staff in-app notification on new request: appointment_requests
--    notifies every admin via on_new_appointment_request_notify ->
--    notify_admin_new_appointment_request(), which litigation_service_
--    requests never had, despite the submit dialog's toast claiming
--    "Our team has been notified". Mirrors that pattern, but notifies
--    both admin AND employee (this module's roles: ['admin','employee']
--    in adminModules.ts — appointment_requests' admin-only notify is a
--    narrower case, not the pattern to copy for who gets pinged).
-- =====================================================================

CREATE TRIGGER audit_writes_litigation_service_requests
AFTER INSERT OR UPDATE OR DELETE ON public.litigation_service_requests
FOR EACH ROW EXECUTE FUNCTION public.audit_write_event();

CREATE OR REPLACE FUNCTION public.notify_staff_new_litigation_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  staff_user RECORD;
  v_label text;
BEGIN
  v_label := CASE NEW.service_type
    WHEN 'addendum' THEN 'Addendum'
    WHEN 'affidavit' THEN 'Affidavit'
    WHEN 'joint_minutes' THEN 'Joint Minute'
    WHEN 'bundle_preparation' THEN 'Medico-Legal Bundle Preparation'
    WHEN 'report_summary' THEN 'Report Summaries'
    WHEN 'medical_chronology' THEN 'Medical Chronology'
    WHEN 'quantum_calculation' THEN 'Quantum Calculation'
    WHEN 'expert_availability' THEN 'Expert Availability for Trial'
    WHEN 'case_consultation' THEN 'Case Consultation'
    WHEN 'trial_coordination' THEN 'Expert Trial Coordination'
    WHEN 'court_formatting' THEN 'Court-Ready Report Formatting'
    ELSE NEW.service_type
  END;

  FOR staff_user IN
    SELECT DISTINCT ur.user_id FROM public.user_roles ur WHERE ur.role IN ('admin', 'employee')
  LOOP
    INSERT INTO public.notifications (user_id, title, message, type, category, related_record_id, related_table)
    VALUES (
      staff_user.user_id,
      CASE WHEN NEW.urgency = 'critical' THEN '⚖️ Critical Litigation Service Request' ELSE '⚖️ New Litigation Service Request' END,
      v_label || ' requested for ' || NEW.claimant_name ||
        CASE WHEN NEW.urgency <> 'standard' THEN ' (' || initcap(NEW.urgency) || ')' ELSE '' END || '.',
      CASE WHEN NEW.urgency = 'critical' THEN 'warning' ELSE 'info' END,
      'litigation_service_request',
      NEW.id,
      'litigation_service_requests'
    );
  END LOOP;
  RETURN NEW;
END;
$function$;

CREATE TRIGGER on_new_litigation_request_notify
AFTER INSERT ON public.litigation_service_requests
FOR EACH ROW EXECUTE FUNCTION public.notify_staff_new_litigation_request();

COMMENT ON TRIGGER on_new_litigation_request_notify ON public.litigation_service_requests IS
  'Fills the gap where the submit dialog told requesters "Our team has been notified" but nothing actually notified staff — mirrors on_new_appointment_request_notify, extended to employee as well as admin since both action this module.';
