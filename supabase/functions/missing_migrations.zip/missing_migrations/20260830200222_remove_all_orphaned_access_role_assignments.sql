-- Full sweep: these 5 access_role_assignments rows point to user IDs that
-- don't exist in auth.users at all (confirmed via lookup). Dead leftover
-- data from deleted/never-completed accounts -- harmless but cleaned up
-- for a tidy table.
DELETE FROM access_role_assignments
WHERE user_id IN (
  '9c7c9f1f-c246-404f-a972-9bceeee0f9fd',
  '7abb613a-ad2e-40d1-83d6-86c426265ff5',
  'c2c31852-b5b5-419b-bb71-a64920632f70',
  'af71877f-f6a5-406c-b8cf-400a2ebc4b20',
  '79685ce2-2e8b-4f6b-9f30-0fbbf5122205'
);
