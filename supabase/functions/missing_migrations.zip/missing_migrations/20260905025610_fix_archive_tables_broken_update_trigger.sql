-- Same broken pattern as notifications: these two archive tables have
-- no updated_at column, but carry a trigger calling
-- update_updated_at_column(), which unconditionally does
-- `NEW.updated_at = now()`. Nothing in the app updates these tables
-- today, so this hasn't bitten yet — but it's the same landmine, and
-- would silently fail any future UPDATE to either table.
DROP TRIGGER IF EXISTS update_appointment_archives_updated_at ON public.appointment_archives;
DROP TRIGGER IF EXISTS update_assessment_archives_updated_at ON public.assessment_report_archives;
