-- Phase 1 fix: align live role_module_defaults / access_modules with the
-- already-documented intent in src/config/adminModules.ts. Grants only —
-- nothing currently working is revoked.

insert into access_modules (module_key, title, description, group_name, route_path, is_active)
values (
  'assessment-reports',
  'Assessment Reports & Statistics',
  'Assessment performance, completion rates & expert analytics',
  'Workflow',
  '/admin/assessment-reports-statistics',
  true
)
on conflict (module_key) do nothing;

insert into role_module_defaults (role_key, module_key, is_eligible, is_default_on)
values
  ('admin', 'assessment-reports', true, true),
  ('employee', 'assessment-reports', true, true),
  ('director', 'assessment-reports', true, true)
on conflict (role_key, module_key) do update
  set is_eligible = excluded.is_eligible,
      is_default_on = excluded.is_default_on;

update role_module_defaults
set is_eligible = true, is_default_on = true
where role_key = 'employee'
  and module_key in ('attorney-crm', 'sales-dashboard', 'heatmap', 'finance', 'expert-payment-planner');

update role_module_defaults
set is_eligible = true, is_default_on = true
where role_key = 'sales_consultant'
  and module_key = 'find-experts';
