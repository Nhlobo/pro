-- Same defect as 20260830092000, found on a broader sweep for ANY account
-- holding both an internal staff role and an external-portal role.
-- Two more accounts affected:
--
--   worksof28@gmail.com (b4b256d5-4ef5-4b52-b5bb-fa660962259d)
--     Created 2026-08-28 as internal Director staff (real admin grant).
--     Bridged into External Portal TODAY, 2026-08-30 06:21 UTC
--     (granted_by NULL referring_attorney row) — overwrote name and
--     linked a real attorney's referring_attorney_id onto this staff
--     account.
--
--   info@kutlwanoassociate.com (c2c31852-b5b5-419b-bb71-a64920632f70)
--     The firm's own admin mailbox (admin role since 2026-06-01).
--     Bridged into External Portal on 2026-08-28 18:43 UTC (granted_by
--     NULL referring_attorney row) — overwrote name/role/user_type
--     with an attorney contact's. Admin access itself was never lost
--     (user_roles 'admin' row was untouched), but profile display,
--     login routing, and sign-out destination were all wrong.
--
-- Both repaired the same way: drop the injected referring_attorney
-- role, restore role/user_type/is_external_portal_user from the
-- account's genuine remaining staff role, clear the overwritten name
-- and attorney-linkage fields (not guessed — needs admin re-entry).
DELETE FROM public.user_roles
WHERE user_id IN (
  'b4b256d5-4ef5-4b52-b5bb-fa660962259d',
  'c2c31852-b5b5-419b-bb71-a64920632f70'
)
AND role = 'referring_attorney'
AND granted_by IS NULL;

UPDATE public.profiles
SET
  role = 'director',
  user_type = 'user',
  is_external_portal_user = false,
  first_name = NULL,
  last_name = NULL,
  referring_attorney_id = NULL,
  attorney_contact_id = NULL,
  expert_id = NULL
WHERE id = 'b4b256d5-4ef5-4b52-b5bb-fa660962259d';

UPDATE public.profiles
SET
  role = 'admin',
  user_type = 'admin',
  is_external_portal_user = false,
  first_name = NULL,
  last_name = NULL,
  referring_attorney_id = NULL,
  attorney_contact_id = NULL,
  expert_id = NULL
WHERE id = 'c2c31852-b5b5-419b-bb71-a64920632f70';
