# Missing Supabase migrations (repo catch-up)

Your uploaded repo's `supabase/migrations/` folder stops at 2026-09-03.
The live "Medico-Legal Assessment" project (zybkhhxvsdjkluqydcbb) has
105 migrations applied after that point, up to and including this
morning's fix. These files are those 105 migrations, exported directly
from the live database's migration history, named the same way Supabase
CLI names them (`<version>_<name>.sql`).

**The dashboard bug itself is already fixed live** — see
`20260907040033_referring_attorneys_staff_select_policy.sql`, applied
this morning. This bundle exists so your *repo* catches up to match
production, not to apply anything new.

## How to use these

1. Copy every file in this folder into your repo's
   `supabase/migrations/` directory (they sort correctly by filename,
   so they'll slot in right after your existing `20260903120000_...`
   file — a few version numbers will be slightly interleaved with the
   real production order but that's a labeling quirk, not a problem).
2. Do **not** run these against production — they're already applied
   there. This is purely to sync your local/repo history so future
   `supabase db push` or `db reset` runs don't wipe these out.
3. If you have the Supabase CLI and want to double check instead of
   copying manually, you can run:
   ```
   supabase link --project-ref zybkhhxvsdjkluqydcbb
   supabase db pull
   ```
   which will regenerate migration files directly from the live schema
   and is the more "official" way to do this. Either approach gets you
   to the same place.
4. Commit the result. From then on, your repo and production will
   agree, and a future reset/redeploy won't undo any of this work.

## Highlights worth knowing about while you're in here

- `20260907040033_referring_attorneys_staff_select_policy.sql` — the
  fix for the dashboard bug you reported.
- `20260904092817_finance_director_write_access_for_payment_actions.sql`
  and the `optimize_finance_rls_*` series — a large batch of
  finance/director read & write RLS fixes and performance tuning.
- `20260905025547_fix_notifications_broken_update_trigger.sql` and
  `20260905030157_clear_notifications_backlog_before_trigger_fix.sql`
  — these fixed (and then bulk-cleared) a bug where "mark as read" had
  been silently failing on every notification since March 2026.
- `20260829*` series — a large external-portal security lockdown pass
  (RLS tightening, anon access revocation, storage bucket scoping).
