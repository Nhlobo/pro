-- Before this, negligence_analysis_history had SELECT/INSERT policies
-- scoped ONLY to auth.uid() = user_id, and NO UPDATE policy at all.
-- That means: staff could not see analyses created by other staff, and
-- nobody (including admins) could actually action a review even if the
-- UI offered it, because there was no RLS path allowing the UPDATE.
-- This is exactly the gap behind client spec section 10 ("Human Review").
CREATE POLICY "Admins and employees can view all negligence analyses"
  ON public.negligence_analysis_history
  FOR SELECT
  USING (public.is_admin_or_employee());

CREATE POLICY "Admins and employees can review negligence analyses"
  ON public.negligence_analysis_history
  FOR UPDATE
  USING (public.is_admin_or_employee())
  WITH CHECK (public.is_admin_or_employee());
