DO $$
BEGIN
  DROP POLICY IF EXISTS "Admins and employees can view all referring attorneys" ON public.referring_attorneys;

  CREATE POLICY "Admins and employees can view all referring attorneys"
  ON public.referring_attorneys
  FOR SELECT
  TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'employee'::app_role) OR
    is_system_admin()
  );
END $$;

COMMENT ON POLICY "Admins and employees can view all referring attorneys" ON public.referring_attorneys IS
  'Closes the gap where employees could see appointments (admin/employee SELECT policy on appointments) but not the referring_attorneys row each appointment embeds, causing province-based dashboard cards (e.g. Operations Dashboard Provincial Case Distribution) to silently render empty/0 for employee-role staff with no visible error.';
