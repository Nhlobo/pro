UPDATE auth.identities SET identity_data = jsonb_set(identity_data, '{email}', '"nhlobo365@gmail.com"')
WHERE user_id = '2e673e2b-e4b7-40ca-9459-26d44b793a08';
