CREATE OR REPLACE FUNCTION public.enqueue_sageone_invoice_on_appointment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF COALESCE(NEW.service_fee, 0) > 0 OR COALESCE(NEW.deposit_amount, 0) > 0 THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.sageone_invoice_queue q
      WHERE q.appointment_id = NEW.id AND q.status <> 'failed'
    ) THEN
      INSERT INTO public.sageone_invoice_queue (appointment_id, payload)
      VALUES (
        NEW.id,
        jsonb_build_object(
          'appointment_id', NEW.id,
          'appointment_date', NEW.appointment_date,
          'referring_attorney_id', NEW.referring_attorney_id,
          'claimant_id', NEW.claimant_id,
          'expert_id', NEW.expert_id,
          'amount', COALESCE(NEW.service_fee, NEW.deposit_amount, 0),
          'currency', 'ZAR',
          'payment_terms', NEW.payment_terms,
          'appointment_reference', NEW.id
        )
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
