-- worksof27@gmail.com (3f8c0957-4a25-4b2b-922f-a1895f83493d): same exact
-- bug as worksof26 -- user_roles says 'sales_consultant' (login/redirect
-- works) but access_role_assignments had no row at all (no pages resolve,
-- infinite loading spinner). Also syncing profiles.role/user_type which
-- were still 'user'.

INSERT INTO access_role_assignments (user_id, role_key, assigned_by)
VALUES ('3f8c0957-4a25-4b2b-922f-a1895f83493d', 'sales_consultant', '99f79b02-e597-4fcb-8556-874004dd9f5f')
ON CONFLICT (user_id) DO UPDATE SET role_key = EXCLUDED.role_key;

UPDATE profiles
SET role = 'sales_consultant', user_type = 'user'
WHERE id = '3f8c0957-4a25-4b2b-922f-a1895f83493d';
