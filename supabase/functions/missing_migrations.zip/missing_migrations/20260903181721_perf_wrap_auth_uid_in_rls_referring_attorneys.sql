ALTER POLICY "Admins and employees can delete referring attorneys" ON public.referring_attorneys
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role) OR is_system_admin());

ALTER POLICY "Admins can view all law firms" ON public.referring_attorneys
USING (EXISTS (SELECT 1 FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'admin'::text) AND (profiles.created_at IS NOT NULL))));

ALTER POLICY "Finance and director can view all law firms" ON public.referring_attorneys
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Only admins can create law firms" ON public.referring_attorneys
WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'admin'::text))));

ALTER POLICY "Only admins can delete law firms" ON public.referring_attorneys
USING (EXISTS (SELECT 1 FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'admin'::text))));

ALTER POLICY "Only admins can update law firms" ON public.referring_attorneys
USING (EXISTS (SELECT 1 FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'admin'::text))))
WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'admin'::text))));

ALTER POLICY "Referring attorneys can update their own profile" ON public.referring_attorneys
USING (id IN (SELECT profiles.referring_attorney_id FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'referring_attorney'::text))))
WITH CHECK (id IN (SELECT profiles.referring_attorney_id FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'referring_attorney'::text))));

ALTER POLICY "Referring attorneys can view their own profile" ON public.referring_attorneys
USING (id IN (SELECT profiles.referring_attorney_id FROM profiles WHERE ((profiles.id = (select auth.uid())) AND (profiles.role = 'referring_attorney'::text))));

ALTER POLICY "Sales consultants can create referring attorneys" ON public.referring_attorneys
WITH CHECK (has_role((select auth.uid()), 'sales_consultant'::app_role));

ALTER POLICY "Sales consultants can update referring attorneys" ON public.referring_attorneys
USING (has_role((select auth.uid()), 'sales_consultant'::app_role))
WITH CHECK (has_role((select auth.uid()), 'sales_consultant'::app_role));

ALTER POLICY "Sales consultants can view all referring attorneys" ON public.referring_attorneys
USING (has_role((select auth.uid()), 'sales_consultant'::app_role));

ALTER POLICY "Users can view own law firm only" ON public.referring_attorneys
USING (
  ((select auth.uid()) IS NOT NULL) AND (id IS NOT NULL) AND
  (EXISTS (SELECT 1 FROM profiles p WHERE ((p.id = (select auth.uid())) AND (p.referring_attorney_id = referring_attorneys.id) AND (p.referring_attorney_id IS NOT NULL) AND (p.created_at IS NOT NULL) AND (p.created_at <= now()))))
);

ALTER POLICY "Users can view own referring attorney only" ON public.referring_attorneys
USING (
  ((select auth.uid()) IS NOT NULL) AND (id IS NOT NULL) AND (
    (EXISTS (SELECT 1 FROM profiles p WHERE ((p.id = (select auth.uid())) AND (p.referring_attorney_id = referring_attorneys.id) AND (p.referring_attorney_id IS NOT NULL) AND (p.created_at IS NOT NULL) AND (p.created_at <= now()))))
    OR ((get_current_user_expert_id() IS NOT NULL) AND (EXISTS (SELECT 1 FROM appointments a WHERE ((a.referring_attorney_id = referring_attorneys.id) AND (a.expert_id = get_current_user_expert_id())))))
  )
);
