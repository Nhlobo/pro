-- 1. Sync fix: role_module_defaults for sales_consultant still had 'finance' and
-- 'appointments' turned on, even though: (a) the code comment next to 'finance'
-- in src/config/adminModules.ts already says "sales_consultant deliberately
-- excluded", and (b) RLS on every table both pages read (aod_documents,
-- short_term_agreements, internal_invoices, audit_logs, appointments) has never
-- granted sales_consultant a single row. Both pages have been fully dead/empty
-- for this role while still showing live-looking admin controls (Record
-- Payment, Full Sync, New Appointment, checklist actions) that would fail if
-- clicked. Turning both off so the nav entry and direct-URL access disappear,
-- matching what the database already enforces everywhere else.
UPDATE public.role_module_defaults
SET is_eligible = false, is_default_on = false
WHERE role_key = 'sales_consultant' AND module_key IN ('finance', 'appointments');

-- 2. The "Attorney & Expert Portal Access" page (external-portal-access module)
-- was correctly scoped to employee + sales_consultant in the nav config and in
-- the frontend (a narrower page than the full admin External Portal module),
-- but the actual tables it reads/writes had ONLY an admin-only RLS policy —
-- so the page was completely non-functional for its intended audience: empty
-- account list, and "Create Portal Account" would fail outright.
--
-- Adding SELECT + INSERT for employee/sales_consultant on the two tables this
-- page needs to list accounts and create new ones. Deliberately NOT touching
-- UPDATE/DELETE here — account status changes (pause/expire/delete) are
-- separately gated admin-only inside the external_portal_set_account_status
-- RPC (SECURITY DEFINER, checked independently of table-level RLS), and that
-- boundary is intentionally left untouched.
CREATE POLICY external_portal_accounts_staff_select
  ON public.external_portal_accounts FOR SELECT
  USING (has_role(auth.uid(), 'employee'::app_role) OR has_role(auth.uid(), 'sales_consultant'::app_role));

CREATE POLICY external_portal_accounts_staff_insert
  ON public.external_portal_accounts FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'employee'::app_role) OR has_role(auth.uid(), 'sales_consultant'::app_role));

-- external_portal_access_links: same audience needs to SEE existing link
-- status (pending/used/expired/revoked) to do their job. Writing to this
-- table (generate/revoke) goes exclusively through the external-portal-
-- admin-links Edge Function (service-role client, its own role check) —
-- so no INSERT/UPDATE policy is added here; a direct-table write attempt
-- from a non-admin client still correctly fails.
CREATE POLICY external_portal_access_links_staff_select
  ON public.external_portal_access_links FOR SELECT
  USING (has_role(auth.uid(), 'employee'::app_role) OR has_role(auth.uid(), 'sales_consultant'::app_role));
