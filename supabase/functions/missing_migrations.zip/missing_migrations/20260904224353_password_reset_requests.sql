CREATE TABLE public.password_reset_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email_lower text NOT NULL,
  ip_address text,
  user_agent text,
  outcome text NOT NULL CHECK (outcome IN ('sent', 'rate_limited_email', 'rate_limited_ip', 'rate_limited_global', 'error')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.password_reset_requests TO service_role;
ALTER TABLE public.password_reset_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins read reset requests" ON public.password_reset_requests FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE INDEX password_reset_requests_email_idx ON public.password_reset_requests(email_lower, created_at DESC);
CREATE INDEX password_reset_requests_ip_idx ON public.password_reset_requests(ip_address, created_at DESC);
CREATE INDEX password_reset_requests_outcome_idx ON public.password_reset_requests(outcome, created_at DESC);
