-- One-time cleanup: mark-as-read was broken system-wide (see
-- 20260905025613_fix_notifications_and_archive_broken_update_triggers.sql)
-- since March 2026, so every notification created before that fix
-- landed is stuck "unread" through no fault of the recipient. Give
-- everyone a clean slate as of the fix — this is a one-off backfill,
-- not something to re-run.
UPDATE public.notifications
SET is_read = true,
    read_at = now()
WHERE is_read = false;
