-- expert_reports
ALTER POLICY "Admins and employees can view all expert reports" ON public.expert_reports
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role) OR
  ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false))
   AND (EXISTS (SELECT 1 FROM appointments a WHERE ((a.id = expert_reports.appointment_id) AND (a.referring_attorney_id = get_current_user_referring_attorney())))))
);

ALTER POLICY "Finance and director can view all expert reports" ON public.expert_reports
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can view expert reports from their referring attorney" ON public.expert_reports
USING (
  (EXISTS (SELECT 1 FROM appointments a WHERE (
    (a.id = expert_reports.appointment_id) AND (a.deleted_at IS NULL) AND (
      ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false)) AND (a.referring_attorney_id = get_current_user_referring_attorney()))
      OR ((get_current_user_portal_account_scope() = 'firm'::external_portal_account_scope) AND (a.referring_attorney_id = get_current_user_referring_attorney()))
      OR ((get_current_user_portal_account_scope() = 'individual'::external_portal_account_scope) AND (a.assigned_attorney_contact_id IS NOT NULL) AND (a.assigned_attorney_contact_id = get_current_user_attorney_contact()))
    )
  )))
  OR ((get_current_user_expert_id() IS NOT NULL) AND (expert_id = get_current_user_expert_id()))
);

-- medical_experts
ALTER POLICY "Admins and employees can create medical experts" ON public.medical_experts
WITH CHECK (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Admins and employees can update medical experts" ON public.medical_experts
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role))
WITH CHECK (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Authenticated users can view active medical experts" ON public.medical_experts
USING (
  (NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE (p.id = (select auth.uid()))), false))
  OR ((get_current_user_expert_id() IS NOT NULL) AND (id = get_current_user_expert_id()))
  OR ((get_current_user_portal_account_scope() = 'firm'::external_portal_account_scope) AND (EXISTS (SELECT 1 FROM appointments a WHERE ((a.expert_id = medical_experts.id) AND (a.referring_attorney_id = get_current_user_referring_attorney()) AND (a.deleted_at IS NULL)))))
  OR ((get_current_user_portal_account_scope() = 'individual'::external_portal_account_scope) AND (get_current_user_attorney_contact() IS NOT NULL) AND (EXISTS (SELECT 1 FROM appointments a WHERE ((a.expert_id = medical_experts.id) AND (a.assigned_attorney_contact_id = get_current_user_attorney_contact()) AND (a.deleted_at IS NULL)))))
);

ALTER POLICY "Only admins can delete medical experts" ON public.medical_experts
USING (has_role((select auth.uid()), 'admin'::app_role));

ALTER POLICY "Staff can view medical experts" ON public.medical_experts
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role)
);
