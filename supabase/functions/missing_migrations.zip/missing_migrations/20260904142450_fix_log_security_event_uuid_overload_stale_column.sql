-- This is the other overload of log_security_event (p_resource_id uuid) --
-- it still referenced profiles.law_firm_id, which was renamed to
-- referring_attorney_id. Fixing for the same reason as the text overload.
CREATE OR REPLACE FUNCTION public.log_security_event(p_event_type text, p_resource_type text, p_action text, p_resource_id uuid DEFAULT NULL::uuid, p_details jsonb DEFAULT NULL::jsonb, p_risk_level text DEFAULT 'low'::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  audit_id uuid;
  user_profile RECORD;
  client_info jsonb := '{}';
BEGIN
  SELECT id, email, role, referring_attorney_id INTO user_profile
  FROM public.profiles
  WHERE id = auth.uid();

  client_info := jsonb_build_object(
    'ip_address', coalesce(current_setting('request.headers', true)::json->>'x-forwarded-for', 'unknown'),
    'user_agent', coalesce(current_setting('request.headers', true)::json->>'user-agent', 'unknown'),
    'timestamp', now(),
    'risk_level', p_risk_level
  );

  INSERT INTO public.audit_logs (
    table_name,
    record_id,
    action_type,
    user_id,
    user_email,
    function_area,
    description,
    new_values,
    ip_address,
    user_agent
  ) VALUES (
    p_resource_type,
    p_resource_id,
    p_action,
    auth.uid(),
    user_profile.email,
    'security_compliance',
    format('Security Event: %s - %s', p_event_type, p_action),
    jsonb_build_object(
      'event_type', p_event_type,
      'details', p_details,
      'client_info', client_info
    ),
    client_info->>'ip_address',
    client_info->>'user_agent'
  ) RETURNING id INTO audit_id;

  RETURN audit_id;
END;
$function$;
