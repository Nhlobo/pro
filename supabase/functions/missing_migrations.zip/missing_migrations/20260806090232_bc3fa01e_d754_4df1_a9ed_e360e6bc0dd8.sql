GRANT EXECUTE ON FUNCTION public.is_system_admin() TO anon;
GRANT EXECUTE ON FUNCTION public.get_current_user_referring_attorney() TO anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO anon;
