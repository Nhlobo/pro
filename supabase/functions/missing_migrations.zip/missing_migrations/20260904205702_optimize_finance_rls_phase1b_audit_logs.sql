-- finish audit_logs: wrap remaining unwrapped auth.uid() calls
ALTER POLICY "System can insert audit logs" ON public.audit_logs
WITH CHECK ((select auth.uid()) = user_id);

ALTER POLICY "Staff can view audit logs" ON public.audit_logs
USING (
  has_role((select auth.uid()), 'admin'::app_role)
  OR has_role((select auth.uid()), 'employee'::app_role)
  OR has_role((select auth.uid()), 'director'::app_role)
);
