-- ===== external_portal_agreements / payments / audit_logs =====
ALTER POLICY "External portal users view their own firm's agreements" ON public.external_portal_agreements
USING (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
      AND referring_attorney_id = (select get_current_user_referring_attorney()))
  OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope AND referring_attorney_id = (select get_current_user_referring_attorney()))
);

ALTER POLICY "External portal users view payments on their own agreements" ON public.external_portal_agreement_payments
USING (
  (select is_system_admin()) OR has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR EXISTS (SELECT 1 FROM external_portal_agreements a WHERE a.id = external_portal_agreement_payments.aod_document_id)
);

ALTER POLICY "Admins view external portal audit logs" ON public.external_portal_audit_logs
USING (has_role((select auth.uid()), 'admin'::app_role));

-- ===== internal_invoice_delivery_queue =====
ALTER POLICY "System admins full access to internal_invoice_delivery_queue" ON public.internal_invoice_delivery_queue
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Staff can retry a failed internal invoice delivery" ON public.internal_invoice_delivery_queue
WITH CHECK (status = 'pending'::text AND (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role)
));

ALTER POLICY "Admin and employees can view internal_invoice_delivery_queue" ON public.internal_invoice_delivery_queue
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Finance and director can view internal_invoice_delivery_queue" ON public.internal_invoice_delivery_queue
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

-- ===== internal_invoice_email_log =====
ALTER POLICY "System admins full access to internal_invoice_email_log" ON public.internal_invoice_email_log
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Admin and employees can view internal_invoice_email_log" ON public.internal_invoice_email_log
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Finance and director can view internal_invoice_email_log" ON public.internal_invoice_email_log
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

-- ===== internal_invoice_events =====
ALTER POLICY "View invoice events for visible invoices" ON public.internal_invoice_events
USING (EXISTS (
  SELECT 1 FROM internal_invoices ii JOIN profiles p ON p.id = (select auth.uid())
  WHERE ii.id = internal_invoice_events.internal_invoice_id AND (p.role = 'admin'::text OR p.referring_attorney_id = ii.referring_attorney_id)
));

-- ===== internal_invoices =====
ALTER POLICY "Admin and employees can view internal_invoices" ON public.internal_invoices
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Finance and director can view internal_invoices" ON public.internal_invoices
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "View invoices from own referring attorney" ON public.internal_invoices
USING (EXISTS (SELECT 1 FROM profiles WHERE profiles.id = (select auth.uid()) AND (profiles.role = 'admin'::text OR profiles.referring_attorney_id = internal_invoices.referring_attorney_id)));
