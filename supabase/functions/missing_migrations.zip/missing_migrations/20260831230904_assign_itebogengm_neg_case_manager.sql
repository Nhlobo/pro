
insert into staff_access_profiles (user_id, role_key, position_key, is_active)
select p.id, 'employee', 'neg_case_manager', true
from profiles p
where p.email = 'itebogengm@kutlwanoassociate.com'
on conflict (user_id) do update
  set role_key = excluded.role_key,
      position_key = excluded.position_key,
      is_active = true,
      updated_at = now();

update profiles p
set position = sp.display_name
from staff_access_profiles sap
join staff_positions sp on sp.position_key = sap.position_key and sp.role_key = sap.role_key
where sap.user_id = p.id
  and sap.is_active
  and p.email = 'itebogengm@kutlwanoassociate.com';
