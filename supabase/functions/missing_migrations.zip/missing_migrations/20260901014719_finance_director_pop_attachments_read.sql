-- Additive, SELECT-only, finance/director-only. Fixes: finance/director
-- could already upload their own Proof-of-Payment attachment (via the
-- existing unrestricted "Users insert own POPs" policy) but could not
-- see a POP uploaded by anyone else on staff, because the broader
-- staff-visibility policy on this table routes through
-- is_admin_or_employee() -- a third, separate legacy check (distinct
-- from is_system_admin()/has_role) that is also admin/employee only.
CREATE POLICY "Finance and director can view all payment POPs"
ON public.payment_pop_attachments
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'finance'::app_role)
  OR has_role(auth.uid(), 'director'::app_role)
);
