-- Phase 2: same mechanical fix (wrap auth.uid()/session-scoped helper functions in
-- (select ...) so Postgres evaluates them once per query, not once per row) applied
-- across the rest of the Finance & Payments module. No access semantics changed.

-- ===== agreement_annexures =====
ALTER POLICY "System admins full access to annexures" ON public.agreement_annexures
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Users can manage annexures for their agreements" ON public.agreement_annexures
USING (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role))
WITH CHECK (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role));

ALTER POLICY "Users can view annexures for their agreements" ON public.agreement_annexures
USING (
  (agreement_type = 'aod'::text AND EXISTS (
    SELECT 1 FROM aod_documents
    WHERE aod_documents.id = agreement_annexures.agreement_id
      AND aod_documents.referring_attorney_id = (select get_current_user_referring_attorney())))
  OR (agreement_type = 'short_term'::text AND EXISTS (
    SELECT 1 FROM short_term_agreements
    WHERE short_term_agreements.id = agreement_annexures.agreement_id
      AND short_term_agreements.referring_attorney_id = (select get_current_user_referring_attorney())))
);

-- ===== aod_documents =====
ALTER POLICY "Main admin full access to AOD documents" ON public.aod_documents
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "System admins full access to aod documents" ON public.aod_documents
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Users can delete AOD documents from their referring attorney" ON public.aod_documents
USING (referring_attorney_id = (select get_current_user_referring_attorney()));

ALTER POLICY "Users can create AOD documents for their referring attorney" ON public.aod_documents
WITH CHECK (referring_attorney_id = (select get_current_user_referring_attorney()) AND uploaded_by = (select auth.uid()));

ALTER POLICY "Admins and employees can view all AOD documents" ON public.aod_documents
USING (
  has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
  OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
      AND referring_attorney_id = (select get_current_user_referring_attorney()))
  OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope
      AND referring_attorney_id = (select get_current_user_referring_attorney()))
);

ALTER POLICY "Finance and director can view all AOD documents" ON public.aod_documents
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can view AOD documents from their referring attorney" ON public.aod_documents
USING (referring_attorney_id = (select get_current_user_referring_attorney()));

ALTER POLICY "Finance and director can update AOD documents" ON public.aod_documents
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role))
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can update AOD documents from their referring attorney" ON public.aod_documents
USING (referring_attorney_id = (select get_current_user_referring_attorney()));

-- ===== aod_payments =====
ALTER POLICY "Main admin full access to AOD payments" ON public.aod_payments
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "System admins full access to aod payments" ON public.aod_payments
USING ((select is_system_admin())) WITH CHECK ((select is_system_admin()));

ALTER POLICY "Finance and director can create AOD payments" ON public.aod_payments
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can create payments for their referring attorney" ON public.aod_payments
WITH CHECK (EXISTS (
  SELECT 1 FROM aod_documents
  WHERE aod_documents.id = aod_payments.aod_document_id
    AND (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
      OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
          AND aod_documents.referring_attorney_id = (select get_current_user_referring_attorney()))
      OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope
          AND aod_documents.referring_attorney_id = (select get_current_user_referring_attorney())))
));

ALTER POLICY "Finance and director can view all AOD payments" ON public.aod_payments
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can view payments from their referring attorney" ON public.aod_payments
USING (EXISTS (
  SELECT 1 FROM aod_documents
  WHERE aod_documents.id = aod_payments.aod_document_id
    AND (((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
          AND aod_documents.referring_attorney_id = (select get_current_user_referring_attorney()))
      OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope
          AND aod_documents.referring_attorney_id = (select get_current_user_referring_attorney())))
));

ALTER POLICY "Finance and director can update AOD payments" ON public.aod_payments
USING (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role))
WITH CHECK (has_role((select auth.uid()), 'finance'::app_role) OR has_role((select auth.uid()), 'director'::app_role));

ALTER POLICY "Users can update payments from their referring attorney" ON public.aod_payments
USING (EXISTS (
  SELECT 1 FROM aod_documents
  WHERE aod_documents.id = aod_payments.aod_document_id
    AND (has_role((select auth.uid()), 'admin'::app_role) OR has_role((select auth.uid()), 'employee'::app_role)
      OR ((NOT COALESCE((SELECT p.is_external_portal_user FROM profiles p WHERE p.id = (select auth.uid())), false))
          AND aod_documents.referring_attorney_id = (select get_current_user_referring_attorney()))
      OR ((select get_current_user_portal_account_scope()) = 'firm'::external_portal_account_scope
          AND aod_documents.referring_attorney_id = (select get_current_user_referring_attorney())))
));
