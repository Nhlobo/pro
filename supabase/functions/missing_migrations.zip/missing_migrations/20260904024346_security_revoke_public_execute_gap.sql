-- Follow-up correction: these functions still had EXECUTE granted to the
-- PUBLIC pseudo-role (the default when a function is created and never
-- explicitly locked down). PUBLIC applies to every role including anon, so
-- last migration's `REVOKE ... FROM anon` on these specific ones had no real
-- effect — anon could still call them via the PUBLIC grant.
-- `authenticated` already has its own separate, explicit grant on each of
-- these (confirmed via information_schema.routine_privileges before running
-- this), so revoking PUBLIC does not remove authenticated's access.

REVOKE EXECUTE ON FUNCTION public.external_portal_staff_send_message(uuid, uuid, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.new_access_has_module(uuid, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.new_access_is_admin(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.new_access_role_position_allowed(text, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.notify_staff_new_litigation_request() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.touch_new_access_updated_at() FROM PUBLIC;
