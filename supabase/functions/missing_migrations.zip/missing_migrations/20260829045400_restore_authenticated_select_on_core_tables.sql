-- Restore SELECT for authenticated on tables that lost it during the
-- external portal lockdown. RLS policies on these tables already
-- correctly scope rows per-user (staff vs referring attorney vs
-- expert vs external portal account), so this does not widen access -
-- it just lets RLS run at all for legitimate authenticated users.
-- anon is intentionally left without SELECT.

GRANT SELECT ON TABLE public.appointments TO authenticated;
GRANT SELECT ON TABLE public.case_timelines TO authenticated;
GRANT SELECT ON TABLE public.claimants TO authenticated;
GRANT SELECT ON TABLE public.expert_reports TO authenticated;
GRANT SELECT ON TABLE public.medical_experts TO authenticated;
