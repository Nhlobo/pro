DELETE FROM auth.identities WHERE user_id = 'b4b256d5-4ef5-4b52-b5bb-fa660962259d';
DELETE FROM auth.users WHERE id = 'b4b256d5-4ef5-4b52-b5bb-fa660962259d';
