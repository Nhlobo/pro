UPDATE auth.users SET email = 'nhlobo365@gmail.com' WHERE id = '2e673e2b-e4b7-40ca-9459-26d44b793a08';
